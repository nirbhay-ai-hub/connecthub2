const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_101";
const BOB_UID = "bob_uid_202";
const CHARLIE_UID = "charlie_uid_303";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pairId(a, b) {
  return a < b ? `${a}__${b}` : `${b}__${a}`;
}

function nowPast() {
  return new Date(Date.now() - 2000);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: denied across all collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").where("profileDiscoverable", "==", true).get());
  await assertFails(unauthDb.collection("posts").where("visibility", "==", "PUBLIC").get());
  await assertFails(unauthDb.collection("notifications").where("recipientId", "==", ALICE_UID).get());
  await assertFails(unauthDb.collection("conversations").where("memberIds", "array-contains", ALICE_UID).get());
});

test("Profile registration, case-insensitive username uniqueness, and PII isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const ts = nowPast();

  // Atomic batch: username reservation + public profile + private PII doc
  const batch = aliceDb.batch();
  batch.set(aliceDb.collection("usernames").doc("alice_dev"), {
    uid: ALICE_UID,
    username: "Alice_Dev",
    createdAt: ts,
  });
  batch.set(aliceDb.collection("users").doc(ALICE_UID), {
    uid: ALICE_UID,
    displayName: "Alice Rivera",
    displayNameLowercase: "alice rivera",
    username: "Alice_Dev",
    usernameLowercase: "alice_dev",
    bio: "Building social apps",
    interests: ["Android", "Compose"],
    profileDiscoverable: true,
    profileVisibility: "PUBLIC",
    defaultPostVisibility: "FRIENDS",
    allowUnknownMessages: false,
    connectionCount: 0,
    createdAt: ts,
    updatedAt: ts,
  });
  batch.set(aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account"), {
    uid: ALICE_UID,
    email: "alice@example.com",
    acceptedTerms: true,
    notifyFriendRequests: true,
    notifyMessages: true,
    notifyPostActivity: true,
    createdAt: ts,
    updatedAt: ts,
  });
  await assertSucceeds(batch.commit());

  // Bob cannot claim Alice's already-reserved username
  await assertFails(
    bobDb.collection("usernames").doc("alice_dev").set({
      uid: BOB_UID,
      username: "alice_dev",
      createdAt: ts,
    })
  );

  // Bob CAN read Alice's discoverable public profile
  await assertSucceeds(bobDb.collection("users").doc(ALICE_UID).get());
  await assertSucceeds(bobDb.collection("users").where("profileDiscoverable", "==", true).get());

  // Unfiltered user list query MUST fail
  await assertFails(bobDb.collection("users").get());

  // Bob CANNOT read Alice's private PII document
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("private").doc("account").get());

  // Bob CANNOT update Alice's profile or inject shadow fields
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({ bio: "Hacked", updatedAt: nowPast() })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({ isVerified: true, updatedAt: nowPast() })
  );
});

test("Friend request lifecycle, atomic friendship + conversation creation, and private chat isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const ts = nowPast();
  const reqId = `${ALICE_UID}__${BOB_UID}`;
  const convId = pairId(ALICE_UID, BOB_UID);
  const sortedMembers = ALICE_UID < BOB_UID ? [ALICE_UID, BOB_UID] : [BOB_UID, ALICE_UID];

  // Charlie cannot create a conversation with Alice without a friendship
  await assertFails(
    charlieDb.collection("conversations").doc(pairId(ALICE_UID, CHARLIE_UID)).set({
      memberIds: ALICE_UID < CHARLIE_UID ? [ALICE_UID, CHARLIE_UID] : [CHARLIE_UID, ALICE_UID],
      memberNames: { [ALICE_UID]: "Alice", [CHARLIE_UID]: "Charlie" },
      memberUsernames: { [ALICE_UID]: "alice_dev", [CHARLIE_UID]: "charlie" },
      memberPhotos: {},
      lastMessageText: "",
      lastMessageSenderId: "",
      lastMessageAt: ts,
      unreadCounts: { [ALICE_UID]: 0, [CHARLIE_UID]: 0 },
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Alice sends friend request to Bob
  await assertSucceeds(
    aliceDb.collection("friendRequests").doc(reqId).set({
      senderId: ALICE_UID,
      receiverId: BOB_UID,
      senderName: "Alice Rivera",
      senderUsername: "Alice_Dev",
      receiverName: "Bob Chen",
      receiverUsername: "bob_c",
      status: "PENDING",
      memberIds: [ALICE_UID, BOB_UID],
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Alice cannot accept her own sent request
  await assertFails(
    aliceDb.collection("friendRequests").doc(reqId).update({
      status: "ACCEPTED",
      updatedAt: nowPast(),
    })
  );

  // Bob atomically accepts friend request + creates friendship + creates conversation
  const acceptBatch = bobDb.batch();
  acceptBatch.update(bobDb.collection("friendRequests").doc(reqId), {
    status: "ACCEPTED",
    updatedAt: nowPast(),
  });
  acceptBatch.set(bobDb.collection("friendships").doc(convId), {
    memberIds: sortedMembers,
    user1Id: sortedMembers[0],
    user2Id: sortedMembers[1],
    requestId: reqId,
    createdAt: nowPast(),
  });
  acceptBatch.set(bobDb.collection("conversations").doc(convId), {
    memberIds: sortedMembers,
    memberNames: { [ALICE_UID]: "Alice Rivera", [BOB_UID]: "Bob Chen" },
    memberUsernames: { [ALICE_UID]: "Alice_Dev", [BOB_UID]: "bob_c" },
    memberPhotos: {},
    lastMessageText: "Connected on ConnectHub",
    lastMessageSenderId: BOB_UID,
    lastMessageAt: nowPast(),
    unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 0 },
    createdAt: nowPast(),
    updatedAt: nowPast(),
  });
  await assertSucceeds(acceptBatch.commit());

  // Alice sends real-time message in conversation
  await assertSucceeds(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("msg_1").set({
      conversationId: convId,
      senderId: ALICE_UID,
      memberIds: sortedMembers,
      text: "Hey Bob!",
      readBy: [ALICE_UID],
      createdAt: nowPast(),
    })
  );

  // Alice cannot spoof Bob as senderId
  await assertFails(
    aliceDb.collection("conversations").doc(convId).collection("messages").doc("msg_spoof").set({
      conversationId: convId,
      senderId: BOB_UID,
      memberIds: sortedMembers,
      text: "Spoofed!",
      readBy: [BOB_UID],
      createdAt: nowPast(),
    })
  );

  // Charlie cannot read conversation, direct message, or run unfiltered message list
  await assertFails(charlieDb.collection("conversations").doc(convId).get());
  await assertFails(charlieDb.collection("conversations").doc(convId).collection("messages").doc("msg_1").get());
  await assertFails(charlieDb.collection("conversations").doc(convId).collection("messages").get());
  const charlieMsgs = await assertSucceeds(
    charlieDb.collection("conversations").doc(convId).collection("messages").where("memberIds", "array-contains", CHARLIE_UID).get()
  );
  if (!charlieMsgs.empty) {
    throw new Error("Expected empty result for non-member query");
  }

  // Alice and Bob CAN query messages scoped by memberIds
  await assertSucceeds(
    bobDb.collection("conversations").doc(convId).collection("messages").where("memberIds", "array-contains", BOB_UID).get()
  );
});

test("Posts visibility, likes, comments, and blocking enforcement", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const ts = nowPast();

  // Alice creates a FRIENDS post visible to Bob, not Charlie
  await assertSucceeds(
    aliceDb.collection("posts").doc("post_friends").set({
      authorId: ALICE_UID,
      authorName: "Alice Rivera",
      authorUsername: "Alice_Dev",
      text: "Friends-only update!",
      media: [],
      visibility: "FRIENDS",
      friendAudienceIds: [ALICE_UID, BOB_UID],
      likeCount: 0,
      commentCount: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Alice creates a PRIVATE post
  await assertSucceeds(
    aliceDb.collection("posts").doc("post_private").set({
      authorId: ALICE_UID,
      authorName: "Alice Rivera",
      authorUsername: "Alice_Dev",
      text: "Private journal note",
      media: [],
      visibility: "PRIVATE",
      friendAudienceIds: [],
      likeCount: 0,
      commentCount: 0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Bob can query friends posts, Charlie cannot read Alice's private post or friends post
  await assertSucceeds(bobDb.collection("posts").where("friendAudienceIds", "array-contains", BOB_UID).get());
  await assertFails(charlieDb.collection("posts").doc("post_friends").get());
  await assertFails(charlieDb.collection("posts").doc("post_private").get());
  await assertFails(charlieDb.collection("posts").get());

  // Bob likes Alice's friends post atomically
  const likeBatch = bobDb.batch();
  likeBatch.set(bobDb.collection("posts").doc("post_friends").collection("likes").doc(BOB_UID), {
    userId: BOB_UID,
    createdAt: nowPast(),
  });
  likeBatch.update(bobDb.collection("posts").doc("post_friends"), {
    likeCount: 1,
    updatedAt: nowPast(),
  });
  await assertSucceeds(likeBatch.commit());

  // Bob cannot overwrite Alice's post text
  await assertFails(
    bobDb.collection("posts").doc("post_friends").update({
      text: "Tampered",
      updatedAt: nowPast(),
    })
  );

  // Alice blocks Charlie -> Charlie can no longer send friend request to Alice
  await assertSucceeds(
    aliceDb.collection("userBlocks").doc(`${ALICE_UID}__${CHARLIE_UID}`).set({
      blockerId: ALICE_UID,
      blockedId: CHARLIE_UID,
      blockedName: "Charlie",
      blockedUsername: "charlie",
      createdAt: nowPast(),
    })
  );

  await assertFails(
    charlieDb.collection("friendRequests").doc(`${CHARLIE_UID}__${ALICE_UID}`).set({
      senderId: CHARLIE_UID,
      receiverId: ALICE_UID,
      senderName: "Charlie",
      senderUsername: "charlie",
      receiverName: "Alice Rivera",
      receiverUsername: "Alice_Dev",
      status: "PENDING",
      memberIds: [CHARLIE_UID, ALICE_UID],
      createdAt: nowPast(),
      updatedAt: nowPast(),
    })
  );

  // Future timestamp tampered payload must fail
  await assertFails(
    aliceDb.collection("posts").doc("post_future").set({
      authorId: ALICE_UID,
      authorName: "Alice Rivera",
      authorUsername: "Alice_Dev",
      text: "Future post",
      media: [],
      visibility: "PUBLIC",
      friendAudienceIds: [],
      likeCount: 0,
      commentCount: 0,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});
