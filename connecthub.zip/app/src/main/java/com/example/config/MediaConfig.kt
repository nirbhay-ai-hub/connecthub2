package com.example.config

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns

/**
 * Centralized media upload configuration.
 * Limits can be adjusted here to match Firebase Storage Security Rules.
 */
object MediaConfig {
    const val MAX_IMAGE_BYTES: Long = 10L * 1024L * 1024L   // 10 MB
    const val MAX_VIDEO_BYTES: Long = 100L * 1024L * 1024L // 100 MB
    const val MAX_POST_ATTACHMENTS: Int = 6

    val ALLOWED_IMAGE_MIME_PREFIX = "image/"
    val ALLOWED_VIDEO_MIME_PREFIX = "video/"

    data class InspectedMedia(
        val uri: Uri,
        val mimeType: String,
        val fileName: String,
        val sizeBytes: Long,
        val isVideo: Boolean
    )

    fun inspectAndValidate(context: Context, uri: Uri, imagesOnly: Boolean = false): Result<InspectedMedia> {
        val resolver = context.contentResolver
        val mimeType = resolver.getType(uri)?.lowercase()
            ?: return Result.failure(IllegalArgumentException("Unable to determine file type."))

        val isImage = mimeType.startsWith(ALLOWED_IMAGE_MIME_PREFIX)
        val isVideo = mimeType.startsWith(ALLOWED_VIDEO_MIME_PREFIX)

        if (!isImage && (!isVideo || imagesOnly)) {
            return Result.failure(
                IllegalArgumentException(
                    if (imagesOnly) "Only image files are supported here."
                    else "Only image and video files are supported."
                )
            )
        }

        var fileName = "upload_${System.currentTimeMillis()}"
        var sizeBytes = -1L

        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) {
                        cursor.getString(nameIdx)?.takeIf { it.isNotBlank() }?.let { fileName = it }
                    }
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        sizeBytes = cursor.getLong(sizeIdx)
                    }
                }
            }

        if (sizeBytes < 0L) {
            sizeBytes = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
        }

        val maxLimit = if (isVideo) MAX_VIDEO_BYTES else MAX_IMAGE_BYTES
        val maxMb = maxLimit / (1024L * 1024L)
        if (sizeBytes > maxLimit) {
            return Result.failure(
                IllegalArgumentException("File exceeds maximum allowed size of $maxMb MB.")
            )
        }

        return Result.success(
            InspectedMedia(
                uri = uri,
                mimeType = mimeType,
                fileName = fileName.take(80),
                sizeBytes = sizeBytes,
                isVideo = isVideo
            )
        )
    }
}
