package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class ProfileVisibility(val label: String, val description: String) {
    PUBLIC("Public", "Anyone on ConnectHub can view your profile"),
    FRIENDS_ONLY("Friends Only", "Only accepted friends see full profile details"),
    PRIVATE("Private", "Hidden from search and People You May Know")
}

enum class PostVisibility(val label: String) {
    PUBLIC("Public"),
    FRIENDS("Friends"),
    PRIVATE("Private")
}

enum class FriendRequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    CANCELLED
}

enum class NotificationType {
    FRIEND_REQUEST,
    FRIEND_ACCEPTED,
    MESSAGE,
    LIKE,
    COMMENT
}

enum class ReportTargetType {
    PROFILE,
    POST,
    MESSAGE
}

enum class ThemePreference(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Light"),
    DARK("Dark")
}

inline fun <reified T : Enum<T>> safeEnumValueOf(raw: String?, default: T): T {
    if (raw.isNullOrBlank()) return default
    return enumValues<T>().firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: default
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val displayName: String = "",
    val displayNameLowercase: String = "",
    val username: String = "",
    val usernameLowercase: String = "",
    val photoUrl: String? = null,
    val coverUrl: String? = null,
    val bio: String = "",
    val interests: List<String> = emptyList(),
    val profileDiscoverable: Boolean = true,
    val profileVisibility: String = ProfileVisibility.PUBLIC.name,
    val defaultPostVisibility: String = PostVisibility.FRIENDS.name,
    val allowUnknownMessages: Boolean = false,
    val connectionCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PrivateAccount(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val acceptedTerms: Boolean = true,
    val notifyFriendRequests: Boolean = true,
    val notifyMessages: Boolean = true,
    val notifyPostActivity: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FriendRequest(
    @DocumentId val id: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val senderName: String = "",
    val senderUsername: String = "",
    val senderPhotoUrl: String? = null,
    val receiverName: String = "",
    val receiverUsername: String = "",
    val receiverPhotoUrl: String? = null,
    val status: String = FriendRequestStatus.PENDING.name,
    val memberIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Friendship(
    @DocumentId val id: String = "",
    val memberIds: List<String> = emptyList(),
    val user1Id: String = "",
    val user2Id: String = "",
    val requestId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun otherUserId(currentUserId: String): String =
        if (user1Id == currentUserId) user2Id else user1Id
}

@Keep
@IgnoreExtraProperties
data class MediaItem(
    val url: String = "",
    val type: String = "IMAGE",
    val name: String = ""
) {
    fun toMap(): Map<String, Any> = mapOf(
        "url" to url,
        "type" to type,
        "name" to name
    )
}

@Keep
@IgnoreExtraProperties
data class Post(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorUsername: String = "",
    val authorPhotoUrl: String? = null,
    val text: String = "",
    val media: List<MediaItem> = emptyList(),
    val visibility: String = PostVisibility.FRIENDS.name,
    val friendAudienceIds: List<String> = emptyList(),
    val sharedFromPostId: String? = null,
    val sharedFromAuthorName: String? = null,
    val likeCount: Long = 0L,
    val commentCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PostComment(
    @DocumentId val id: String = "",
    val postId: String = "",
    val postAuthorId: String = "",
    val postVisibility: String = PostVisibility.PUBLIC.name,
    val friendAudienceIds: List<String> = emptyList(),
    val authorId: String = "",
    val authorName: String = "",
    val authorUsername: String = "",
    val authorPhotoUrl: String? = null,
    val text: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val memberIds: List<String> = emptyList(),
    val memberNames: Map<String, String> = emptyMap(),
    val memberUsernames: Map<String, String> = emptyMap(),
    val memberPhotos: Map<String, String> = emptyMap(),
    val lastMessageText: String = "",
    val lastMessageSenderId: String = "",
    @ServerTimestamp val lastMessageAt: Timestamp? = null,
    val unreadCounts: Map<String, Long> = emptyMap(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun partnerId(currentUserId: String): String =
        memberIds.firstOrNull { it != currentUserId } ?: ""

    fun partnerName(currentUserId: String): String =
        memberNames[partnerId(currentUserId)] ?: "ConnectHub Member"

    fun partnerUsername(currentUserId: String): String =
        memberUsernames[partnerId(currentUserId)] ?: ""

    fun partnerPhoto(currentUserId: String): String? =
        memberPhotos[partnerId(currentUserId)]?.takeIf { it.isNotBlank() }

    fun unreadFor(currentUserId: String): Long =
        unreadCounts[currentUserId] ?: 0L
}

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val memberIds: List<String> = emptyList(),
    val text: String = "",
    val mediaUrl: String? = null,
    val mediaType: String? = null,
    val readBy: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val recipientId: String = "",
    val actorId: String = "",
    val actorName: String = "",
    val actorPhotoUrl: String? = null,
    val type: String = NotificationType.LIKE.name,
    val description: String = "",
    val targetId: String = "",
    val read: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserBlock(
    @DocumentId val id: String = "",
    val blockerId: String = "",
    val blockedId: String = "",
    val blockedName: String = "",
    val blockedUsername: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ModerationReport(
    @DocumentId val id: String = "",
    val reporterId: String = "",
    val targetType: String = ReportTargetType.POST.name,
    val targetId: String = "",
    val targetOwnerId: String = "",
    val reason: String = "",
    val status: String = "OPEN",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class SuggestedPerson(
    val profile: UserProfile,
    val mutualFriendsCount: Int,
    val sharedInterestsCount: Int,
    val score: Int
)
