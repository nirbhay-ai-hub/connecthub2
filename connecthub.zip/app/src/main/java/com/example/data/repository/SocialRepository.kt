package com.example.data.repository

import com.example.data.firebase.OperationType
import com.example.data.firebase.deterministicPairId
import com.example.data.firebase.handleFirestoreError
import com.example.data.firebase.sortedPairList
import com.example.data.model.FriendRequest
import com.example.data.model.FriendRequestStatus
import com.example.data.model.Friendship
import com.example.data.model.MediaItem
import com.example.data.model.NotificationType
import com.example.data.model.Post
import com.example.data.model.PostComment
import com.example.data.model.PostVisibility
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class SocialRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Authentication required.")

    // --- FRIEND REQUESTS & FRIENDSHIPS ---

    fun observeFriendRequests(userId: String): Flow<List<FriendRequest>> = flow {
        val path = "friendRequests"
        emitAll(
            db.collection("friendRequests")
                .whereArrayContains("memberIds", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FriendRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeFriendships(userId: String): Flow<List<Friendship>> = flow {
        val path = "friendships"
        emitAll(
            db.collection("friendships")
                .whereArrayContains("memberIds", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(Friendship::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun sendFriendRequest(sender: UserProfile, receiver: UserProfile): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (uid != sender.uid || receiver.uid == uid) {
            return Result.failure(IllegalArgumentException("Invalid friend request target."))
        }
        val requestId = "${sender.uid}__${receiver.uid}"
        val path = "friendRequests/$requestId"
        return try {
            val pairId = deterministicPairId(sender.uid, receiver.uid)
            val existingFriendship = db.collection("friendships").document(pairId).get().await()
            if (existingFriendship.exists()) {
                return Result.failure(IllegalStateException("You are already connected."))
            }
            val reverseReq = db.collection("friendRequests").document("${receiver.uid}__${sender.uid}").get().await()
            if (reverseReq.exists() && reverseReq.getString("status") == FriendRequestStatus.PENDING.name) {
                return Result.failure(IllegalStateException("${receiver.displayName} already sent you a request."))
            }

            val existingSelfReq = db.collection("friendRequests").document(requestId).get().await()
            val batch = db.batch()
            if (existingSelfReq.exists()) {
                // Clean up stale non-pending request before sending a new one
                batch.delete(db.collection("friendRequests").document(requestId))
            }

            val payload = mutableMapOf<String, Any?>(
                "senderId" to sender.uid,
                "receiverId" to receiver.uid,
                "senderName" to sender.displayName.take(80),
                "senderUsername" to sender.username.take(30),
                "senderPhotoUrl" to sender.photoUrl?.takeIf { it.isNotBlank() },
                "receiverName" to receiver.displayName.take(80),
                "receiverUsername" to receiver.username.take(30),
                "receiverPhotoUrl" to receiver.photoUrl?.takeIf { it.isNotBlank() },
                "status" to FriendRequestStatus.PENDING.name,
                "memberIds" to listOf(sender.uid, receiver.uid),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            batch.set(db.collection("friendRequests").document(requestId), payload)

            val notifRef = db.collection("notifications").document()
            val notifPayload = mutableMapOf<String, Any?>(
                "recipientId" to receiver.uid,
                "actorId" to sender.uid,
                "actorName" to sender.displayName.take(80),
                "actorPhotoUrl" to sender.photoUrl?.takeIf { it.isNotBlank() },
                "type" to NotificationType.FRIEND_REQUEST.name,
                "description" to "${sender.displayName} sent you a friend request",
                "targetId" to sender.uid,
                "read" to false,
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            batch.set(notifRef, notifPayload)

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun acceptFriendRequest(request: FriendRequest, currentUser: UserProfile): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (request.receiverId != uid) {
            return Result.failure(IllegalArgumentException("Only the recipient can accept this request."))
        }
        val pairId = deterministicPairId(request.senderId, request.receiverId)
        val sortedMembers = sortedPairList(request.senderId, request.receiverId)
        val path = "friendRequests/${request.id}"
        return try {
            val batch = db.batch()
            batch.update(
                db.collection("friendRequests").document(request.id),
                mapOf(
                    "status" to FriendRequestStatus.ACCEPTED.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                db.collection("friendships").document(pairId),
                mapOf(
                    "memberIds" to sortedMembers,
                    "user1Id" to sortedMembers[0],
                    "user2Id" to sortedMembers[1],
                    "requestId" to request.id,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )

            val convRef = db.collection("conversations").document(pairId)
            val existingConv = convRef.get().await()
            if (!existingConv.exists()) {
                val namesMap = mapOf(
                    request.senderId to request.senderName,
                    currentUser.uid to currentUser.displayName
                )
                val usernamesMap = mapOf(
                    request.senderId to request.senderUsername,
                    currentUser.uid to currentUser.username
                )
                val photosMap = mapOf(
                    request.senderId to (request.senderPhotoUrl ?: ""),
                    currentUser.uid to (currentUser.photoUrl ?: "")
                )
                batch.set(
                    convRef,
                    mapOf(
                        "memberIds" to sortedMembers,
                        "memberNames" to namesMap,
                        "memberUsernames" to usernamesMap,
                        "memberPhotos" to photosMap,
                        "lastMessageText" to "Connected on ConnectHub",
                        "lastMessageSenderId" to uid,
                        "lastMessageAt" to FieldValue.serverTimestamp(),
                        "unreadCounts" to mapOf(request.senderId to 0L, currentUser.uid to 0L),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            val notifRef = db.collection("notifications").document()
            val notifPayload = mutableMapOf<String, Any?>(
                "recipientId" to request.senderId,
                "actorId" to currentUser.uid,
                "actorName" to currentUser.displayName.take(80),
                "actorPhotoUrl" to currentUser.photoUrl?.takeIf { it.isNotBlank() },
                "type" to NotificationType.FRIEND_ACCEPTED.name,
                "description" to "${currentUser.displayName} accepted your friend request",
                "targetId" to currentUser.uid,
                "read" to false,
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            batch.set(notifRef, notifPayload)

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun rejectFriendRequest(requestId: String): Result<Unit> {
        val path = "friendRequests/$requestId"
        return try {
            requireUserId()
            db.collection("friendRequests").document(requestId).update(
                mapOf(
                    "status" to FriendRequestStatus.REJECTED.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun cancelFriendRequest(requestId: String): Result<Unit> {
        val path = "friendRequests/$requestId"
        return try {
            requireUserId()
            db.collection("friendRequests").document(requestId).update(
                mapOf(
                    "status" to FriendRequestStatus.CANCELLED.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeFriend(currentUserId: String, friendUserId: String): Result<Unit> {
        val pairId = deterministicPairId(currentUserId, friendUserId)
        val path = "friendships/$pairId"
        return try {
            requireUserId()
            val batch = db.batch()
            batch.delete(db.collection("friendships").document(pairId))
            val reqA = db.collection("friendRequests").document("${currentUserId}__${friendUserId}").get().await()
            if (reqA.exists()) batch.delete(reqA.reference)
            val reqB = db.collection("friendRequests").document("${friendUserId}__${currentUserId}").get().await()
            if (reqB.exists()) batch.delete(reqB.reference)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- POSTS, LIKES, COMMENTS ---

    fun observePublicPosts(limit: Long): Flow<List<Post>> = flow {
        val path = "posts"
        emitAll(
            db.collection("posts")
                .whereEqualTo("visibility", PostVisibility.PUBLIC.name)
                .limit(limit)
                .snapshots()
                .map { snap -> snap.toObjects(Post::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser != null) handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeFriendAudiencePosts(userId: String, limit: Long): Flow<List<Post>> = flow {
        val path = "posts"
        emitAll(
            db.collection("posts")
                .whereArrayContains("friendAudienceIds", userId)
                .limit(limit)
                .snapshots()
                .map { snap -> snap.toObjects(Post::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeOwnPosts(userId: String, limit: Long): Flow<List<Post>> = flow {
        val path = "posts"
        emitAll(
            db.collection("posts")
                .whereEqualTo("authorId", userId)
                .limit(limit)
                .snapshots()
                .map { snap -> snap.toObjects(Post::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun createPost(
        postId: String = db.collection("posts").document().id,
        author: UserProfile,
        text: String,
        media: List<MediaItem>,
        visibility: PostVisibility,
        friendIds: List<String>,
        sharedFromPostId: String? = null,
        sharedFromAuthorName: String? = null
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanText = text.trim().take(2000)
        if (cleanText.isEmpty() && media.isEmpty()) {
            return Result.failure(IllegalArgumentException("Post must contain text or media."))
        }
        val audience = when (visibility) {
            PostVisibility.FRIENDS -> (listOf(uid) + friendIds).distinct().take(250)
            PostVisibility.PUBLIC -> emptyList()
            PostVisibility.PRIVATE -> emptyList()
        }
        val docRef = db.collection("posts").document(postId)
        return try {
            val payload = mutableMapOf<String, Any?>(
                "authorId" to uid,
                "authorName" to author.displayName.take(80),
                "authorUsername" to author.username.take(30),
                "authorPhotoUrl" to author.photoUrl?.takeIf { it.isNotBlank() },
                "text" to cleanText,
                "media" to media.take(6).map { it.toMap() },
                "visibility" to visibility.name,
                "friendAudienceIds" to audience,
                "sharedFromPostId" to sharedFromPostId?.takeIf { it.isNotBlank() },
                "sharedFromAuthorName" to sharedFromAuthorName?.takeIf { it.isNotBlank() }?.take(80),
                "likeCount" to 0L,
                "commentCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updatePostText(post: Post, newText: String, newVisibility: PostVisibility, friendIds: List<String>): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (post.authorId != uid) return Result.failure(IllegalAccessException("Cannot edit someone else's post."))
        val cleanText = newText.trim().take(2000)
        if (cleanText.isEmpty() && post.media.isEmpty()) {
            return Result.failure(IllegalArgumentException("Post cannot be empty."))
        }
        val audience = when (newVisibility) {
            PostVisibility.FRIENDS -> (listOf(uid) + friendIds).distinct().take(250)
            else -> emptyList()
        }
        val docRef = db.collection("posts").document(post.id)
        return try {
            docRef.update(
                mapOf(
                    "text" to cleanText,
                    "visibility" to newVisibility.name,
                    "friendAudienceIds" to audience,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deletePost(postId: String): Result<Unit> {
        val path = "posts/$postId"
        return try {
            requireUserId()
            db.collection("posts").document(postId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun hasUserLikedPost(postId: String, userId: String): Boolean {
        return try {
            db.collection("posts").document(postId).collection("likes").document(userId).get().await().exists()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun toggleLike(post: Post, actor: UserProfile, currentlyLiked: Boolean): Result<Boolean> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val postRef = db.collection("posts").document(post.id)
        val likeRef = postRef.collection("likes").document(uid)
        return try {
            val existing = likeRef.get().await().exists()
            val batch = db.batch()
            if (existing) {
                batch.delete(likeRef)
                batch.update(
                    postRef,
                    mapOf(
                        "likeCount" to FieldValue.increment(-1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.set(
                    likeRef,
                    mapOf(
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    postRef,
                    mapOf(
                        "likeCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                if (post.authorId != uid) {
                    val notifRef = db.collection("notifications").document()
                    val notifPayload = mutableMapOf<String, Any?>(
                        "recipientId" to post.authorId,
                        "actorId" to actor.uid,
                        "actorName" to actor.displayName.take(80),
                        "actorPhotoUrl" to actor.photoUrl?.takeIf { it.isNotBlank() },
                        "type" to NotificationType.LIKE.name,
                        "description" to "${actor.displayName} liked your post",
                        "targetId" to post.id,
                        "read" to false,
                        "createdAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                    batch.set(notifRef, notifPayload)
                }
            }
            batch.commit().await()
            Result.success(!existing)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, postRef.path)
            Result.failure(e)
        }
    }

    fun observeComments(post: Post, currentUserId: String): Flow<List<PostComment>> = flow {
        val path = "posts/${post.id}/comments"
        val base = db.collection("posts").document(post.id).collection("comments")
        val query = when {
            post.authorId == currentUserId -> base.whereEqualTo("postAuthorId", currentUserId)
            post.visibility == PostVisibility.PUBLIC.name -> base.whereEqualTo("postVisibility", PostVisibility.PUBLIC.name)
            else -> base.whereArrayContains("friendAudienceIds", currentUserId)
        }
        emitAll(
            query.snapshots()
                .map { snap ->
                    snap.toObjects(PostComment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser != null) handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun addComment(post: Post, actor: UserProfile, text: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanText = text.trim().take(1000)
        if (cleanText.isEmpty()) return Result.failure(IllegalArgumentException("Comment cannot be empty."))

        val postRef = db.collection("posts").document(post.id)
        val commentRef = postRef.collection("comments").document()
        return try {
            val batch = db.batch()
            val commentPayload = mutableMapOf<String, Any?>(
                "postId" to post.id,
                "postAuthorId" to post.authorId,
                "postVisibility" to post.visibility,
                "friendAudienceIds" to post.friendAudienceIds,
                "authorId" to uid,
                "authorName" to actor.displayName.take(80),
                "authorUsername" to actor.username.take(30),
                "authorPhotoUrl" to actor.photoUrl?.takeIf { it.isNotBlank() },
                "text" to cleanText,
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            batch.set(commentRef, commentPayload)
            batch.update(
                postRef,
                mapOf(
                    "commentCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (post.authorId != uid) {
                val notifRef = db.collection("notifications").document()
                val notifPayload = mutableMapOf<String, Any?>(
                    "recipientId" to post.authorId,
                    "actorId" to actor.uid,
                    "actorName" to actor.displayName.take(80),
                    "actorPhotoUrl" to actor.photoUrl?.takeIf { it.isNotBlank() },
                    "type" to NotificationType.COMMENT.name,
                    "description" to "${actor.displayName} commented: ${cleanText.take(60)}",
                    "targetId" to post.id,
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                batch.set(notifRef, notifPayload)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, commentRef.path)
            Result.failure(e)
        }
    }
}
