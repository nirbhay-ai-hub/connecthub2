package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.config.MediaConfig
import com.example.data.model.MediaItem
import com.google.firebase.Firebase
import com.google.firebase.storage.StorageException
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import java.util.UUID

class MediaStorageRepository(private val context: Context) {
    private val storage = Firebase.storage

    suspend fun uploadProfileImage(
        userId: String,
        uri: Uri,
        kind: String,
        onProgress: (Float) -> Unit = {}
    ): Result<String> {
        val inspected = MediaConfig.inspectAndValidate(context, uri, imagesOnly = true)
            .getOrElse { return Result.failure(it) }
        val safeName = "${kind}_${UUID.randomUUID()}_${sanitizedName(inspected.fileName)}"
        val ref = storage.reference.child("users/$userId/profile/$safeName")
        return uploadInspected(ref, inspected, onProgress).map { it.url }
    }

    suspend fun uploadPostMedia(
        userId: String,
        postId: String,
        uri: Uri,
        onProgress: (Float) -> Unit = {}
    ): Result<MediaItem> {
        val inspected = MediaConfig.inspectAndValidate(context, uri, imagesOnly = false)
            .getOrElse { return Result.failure(it) }
        val safeName = "${UUID.randomUUID()}_${sanitizedName(inspected.fileName)}"
        val ref = storage.reference.child("posts/$userId/$postId/$safeName")
        return uploadInspected(ref, inspected, onProgress)
    }

    suspend fun uploadChatMedia(
        conversationId: String,
        senderId: String,
        uri: Uri,
        onProgress: (Float) -> Unit = {}
    ): Result<MediaItem> {
        val inspected = MediaConfig.inspectAndValidate(context, uri, imagesOnly = false)
            .getOrElse { return Result.failure(it) }
        val safeName = "${UUID.randomUUID()}_${sanitizedName(inspected.fileName)}"
        val ref = storage.reference.child("chats/$conversationId/$senderId/$safeName")
        return uploadInspected(ref, inspected, onProgress)
    }

    private suspend fun uploadInspected(
        ref: com.google.firebase.storage.StorageReference,
        inspected: MediaConfig.InspectedMedia,
        onProgress: (Float) -> Unit
    ): Result<MediaItem> {
        return try {
            val metadata = StorageMetadata.Builder()
                .setContentType(inspected.mimeType)
                .build()
            val task = ref.putFile(inspected.uri, metadata)
            task.addOnProgressListener { snap ->
                val total = snap.totalByteCount
                if (total > 0L) {
                    onProgress((snap.bytesTransferred.toFloat() / total.toFloat()).coerceIn(0f, 1f))
                }
            }
            task.await()
            val downloadUrl = ref.downloadUrl.await().toString()
            onProgress(1f)
            Result.success(
                MediaItem(
                    url = downloadUrl,
                    type = if (inspected.isVideo) "VIDEO" else "IMAGE",
                    name = inspected.fileName
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: StorageException) {
            Log.e("MediaStorageRepo", "Firebase Storage upload failed: code=${e.errorCode}", e)
            val friendly = when (e.errorCode) {
                StorageException.ERROR_BUCKET_NOT_FOUND,
                StorageException.ERROR_PROJECT_NOT_FOUND,
                StorageException.ERROR_OBJECT_NOT_FOUND ->
                    "Firebase Storage is not initialized yet. Enable Storage in the Firebase Console and deploy storage.rules."
                StorageException.ERROR_NOT_AUTHORIZED ->
                    "Storage permission denied. Deploy storage.rules and confirm you are signed in."
                else -> e.localizedMessage ?: "Media upload failed."
            }
            Result.failure(IllegalStateException(friendly, e))
        } catch (e: Exception) {
            Log.e("MediaStorageRepo", "Unexpected upload error", e)
            Result.failure(e)
        }
    }

    private fun sanitizedName(name: String): String =
        name.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(40)
}
