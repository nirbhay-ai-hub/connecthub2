package com.example.data.repository

import com.example.data.firebase.OperationType
import com.example.data.firebase.deterministicPairId
import com.example.data.firebase.handleFirestoreError
import com.example.data.firebase.sortedPairList
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MediaItem
import com.example.data.model.NotificationType
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChatRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Authentication required.")

    fun observeConversations(userId: String): Flow<List<Conversation>> = flow {
        val path = "conversations"
        emitAll(
            db.collection("conversations")
                .whereArrayContains("memberIds", userId)
                .limit(50)
                .snapshots()
                .map { snap ->
                    snap.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.lastMessageAt ?: it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeMessages(conversationId: String, userId: String, limit: Long): Flow<List<ChatMessage>> = flow {
        val path = "conversations/$conversationId/messages"
        emitAll(
            db.collection("conversations").document(conversationId).collection("messages")
                .whereArrayContains("memberIds", userId)
                .limit(limit)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt ?: Timestamp(Long.MAX_VALUE / 2, 0) }
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun openOrCreateConversation(currentUser: UserProfile, partner: UserProfile): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val convId = deterministicPairId(uid, partner.uid)
        val sortedMembers = sortedPairList(uid, partner.uid)
        val convRef = db.collection("conversations").document(convId)
        return try {
            val snap = convRef.get().await()
            if (!snap.exists()) {
                convRef.set(
                    mapOf(
                        "memberIds" to sortedMembers,
                        "memberNames" to mapOf(uid to currentUser.displayName, partner.uid to partner.displayName),
                        "memberUsernames" to mapOf(uid to currentUser.username, partner.uid to partner.username),
                        "memberPhotos" to mapOf(uid to (currentUser.photoUrl ?: ""), partner.uid to (partner.photoUrl ?: "")),
                        "lastMessageText" to "Start chatting",
                        "lastMessageSenderId" to uid,
                        "lastMessageAt" to FieldValue.serverTimestamp(),
                        "unreadCounts" to mapOf(uid to 0L, partner.uid to 0L),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(convId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, convRef.path)
            Result.failure(e)
        }
    }

    suspend fun sendMessage(
        conversation: Conversation,
        sender: UserProfile,
        text: String,
        media: MediaItem? = null
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val cleanText = text.trim().take(2000)
        if (cleanText.isEmpty() && media == null) {
            return Result.failure(IllegalArgumentException("Message cannot be empty."))
        }
        val partnerId = conversation.partnerId(uid)
        val convRef = db.collection("conversations").document(conversation.id)
        val msgRef = convRef.collection("messages").document()
        return try {
            val batch = db.batch()
            val msgPayload = mutableMapOf<String, Any?>(
                "conversationId" to conversation.id,
                "senderId" to uid,
                "memberIds" to conversation.memberIds,
                "text" to cleanText,
                "mediaUrl" to media?.url,
                "mediaType" to media?.type,
                "readBy" to listOf(uid),
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            batch.set(msgRef, msgPayload)

            val preview = when {
                cleanText.isNotEmpty() -> cleanText.take(120)
                media?.type == "VIDEO" -> "Sent a video"
                else -> "Sent a photo"
            }

            val updatedUnread = conversation.unreadCounts.toMutableMap()
            updatedUnread[uid] = 0L
            if (partnerId.isNotBlank()) {
                updatedUnread[partnerId] = (updatedUnread[partnerId] ?: 0L) + 1L
            }

            val updatedNames = conversation.memberNames.toMutableMap().apply { put(uid, sender.displayName) }
            val updatedUsernames = conversation.memberUsernames.toMutableMap().apply { put(uid, sender.username) }
            val updatedPhotos = conversation.memberPhotos.toMutableMap().apply { put(uid, sender.photoUrl ?: "") }

            batch.update(
                convRef,
                mapOf(
                    "lastMessageText" to preview,
                    "lastMessageSenderId" to uid,
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadCounts" to updatedUnread,
                    "memberNames" to updatedNames,
                    "memberUsernames" to updatedUsernames,
                    "memberPhotos" to updatedPhotos,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            if (partnerId.isNotBlank()) {
                val notifRef = db.collection("notifications").document()
                val notifPayload = mutableMapOf<String, Any?>(
                    "recipientId" to partnerId,
                    "actorId" to uid,
                    "actorName" to sender.displayName.take(80),
                    "actorPhotoUrl" to sender.photoUrl?.takeIf { it.isNotBlank() },
                    "type" to NotificationType.MESSAGE.name,
                    "description" to "${sender.displayName}: ${preview.take(60)}",
                    "targetId" to conversation.id,
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                batch.set(notifRef, notifPayload)
            }

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, msgRef.path)
            Result.failure(e)
        }
    }

    suspend fun markConversationRead(conversation: Conversation, messages: List<ChatMessage>): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val convRef = db.collection("conversations").document(conversation.id)
        return try {
            val needsConvUpdate = (conversation.unreadCounts[uid] ?: 0L) > 0L
            val unreadMessages = messages.filter { it.senderId != uid && uid !in it.readBy }
            if (!needsConvUpdate && unreadMessages.isEmpty()) return Result.success(Unit)

            val batch = db.batch()
            if (needsConvUpdate) {
                val updatedUnread = conversation.unreadCounts.toMutableMap()
                updatedUnread[uid] = 0L
                batch.update(
                    convRef,
                    mapOf(
                        "unreadCounts" to updatedUnread,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            unreadMessages.take(25).forEach { msg ->
                batch.update(
                    convRef.collection("messages").document(msg.id),
                    mapOf("readBy" to (msg.readBy + uid).distinct())
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, convRef.path)
            Result.failure(e)
        }
    }
}
