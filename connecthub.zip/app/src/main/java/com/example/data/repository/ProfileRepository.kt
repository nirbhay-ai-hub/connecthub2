package com.example.data.repository

import com.example.data.firebase.OperationType
import com.example.data.firebase.deterministicPairId
import com.example.data.firebase.handleFirestoreError
import com.example.data.model.ModerationReport
import com.example.data.model.PostVisibility
import com.example.data.model.PrivateAccount
import com.example.data.model.ProfileVisibility
import com.example.data.model.ReportTargetType
import com.example.data.model.UserBlock
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ProfileRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Authentication required.")

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser != null) {
                        handleFirestoreError(fsError ?: error, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observePrivateAccount(userId: String): Flow<PrivateAccount?> = flow {
        val path = "users/$userId/private/account"
        emitAll(
            db.collection("users").document(userId).collection("private").document("account")
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(PrivateAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(fsError ?: error, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeDiscoverableUsers(): Flow<List<UserProfile>> = flow {
        val path = "users"
        emitAll(
            db.collection("users")
                .whereEqualTo("profileDiscoverable", true)
                .limit(80)
                .snapshots()
                .map { snap ->
                    snap.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser != null) {
                        handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeBlockedUsers(userId: String): Flow<List<UserBlock>> = flow {
        val path = "userBlocks"
        emitAll(
            db.collection("userBlocks")
                .whereEqualTo("blockerId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(UserBlock::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fsError == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == userId) {
                        handleFirestoreError(fsError ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun getProfileById(userId: String): Result<UserProfile?> {
        val path = "users/$userId"
        return try {
            requireUserId()
            val snap = db.collection("users").document(userId).get().await()
            val profile = if (snap.exists()) {
                snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            } else null
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun isUsernameAvailable(username: String, currentUserId: String): Result<Boolean> {
        val handle = username.trim().lowercase()
        if (!handle.matches(Regex("^[a-z0-9_]{3,30}$"))) {
            return Result.failure(IllegalArgumentException("Username must be 3–30 letters, numbers, or underscores."))
        }
        val path = "usernames/$handle"
        return try {
            val snap = db.collection("usernames").document(handle).get().await()
            val available = !snap.exists() || snap.getString("uid") == currentUserId
            Result.success(available)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun createInitialProfile(
        displayName: String,
        username: String,
        bio: String,
        interests: List<String>,
        photoUrl: String?,
        email: String,
        acceptedTerms: Boolean,
        profileDiscoverable: Boolean
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val trimmedName = displayName.trim().take(80)
        val trimmedUsername = username.trim().take(30)
        val handle = trimmedUsername.lowercase()

        if (trimmedName.isEmpty()) return Result.failure(IllegalArgumentException("Full name is required."))
        if (!handle.matches(Regex("^[a-z0-9_]{3,30}$"))) {
            return Result.failure(IllegalArgumentException("Username must be 3–30 letters, numbers, or underscores."))
        }
        if (!acceptedTerms) {
            return Result.failure(IllegalArgumentException("You must agree to the Terms and Privacy Policy."))
        }

        val path = "users/$uid"
        return try {
            val existingHandle = db.collection("usernames").document(handle).get().await()
            if (existingHandle.exists() && existingHandle.getString("uid") != uid) {
                return Result.failure(IllegalStateException("Username @$trimmedUsername is already taken."))
            }

            val batch = db.batch()
            if (!existingHandle.exists()) {
                val usernamePayload = mapOf(
                    "uid" to uid,
                    "username" to trimmedUsername,
                    "createdAt" to FieldValue.serverTimestamp()
                )
                batch.set(db.collection("usernames").document(handle), usernamePayload)
            }

            val profilePayload = mutableMapOf<String, Any?>(
                "uid" to uid,
                "displayName" to trimmedName,
                "displayNameLowercase" to trimmedName.lowercase(),
                "username" to trimmedUsername,
                "usernameLowercase" to handle,
                "photoUrl" to photoUrl?.takeIf { it.isNotBlank() },
                "bio" to bio.trim().take(300),
                "interests" to interests.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(15),
                "profileDiscoverable" to profileDiscoverable,
                "profileVisibility" to if (profileDiscoverable) ProfileVisibility.PUBLIC.name else ProfileVisibility.PRIVATE.name,
                "defaultPostVisibility" to PostVisibility.FRIENDS.name,
                "allowUnknownMessages" to false,
                "connectionCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            batch.set(db.collection("users").document(uid), profilePayload)

            val privatePayload = mapOf(
                "uid" to uid,
                "email" to email.take(254),
                "acceptedTerms" to true,
                "notifyFriendRequests" to true,
                "notifyMessages" to true,
                "notifyPostActivity" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            batch.set(
                db.collection("users").document(uid).collection("private").document("account"),
                privatePayload
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProfile(
        currentProfile: UserProfile,
        displayName: String,
        username: String,
        bio: String,
        interests: List<String>,
        photoUrl: String?,
        coverUrl: String?
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val trimmedName = displayName.trim().take(80)
        val trimmedUsername = username.trim().take(30)
        val newHandle = trimmedUsername.lowercase()

        if (trimmedName.isEmpty()) return Result.failure(IllegalArgumentException("Name cannot be empty."))
        if (!newHandle.matches(Regex("^[a-z0-9_]{3,30}$"))) {
            return Result.failure(IllegalArgumentException("Username must be 3–30 letters, numbers, or underscores."))
        }

        val path = "users/$uid"
        return try {
            val batch = db.batch()
            if (newHandle != currentProfile.usernameLowercase) {
                val targetSnap = db.collection("usernames").document(newHandle).get().await()
                if (targetSnap.exists() && targetSnap.getString("uid") != uid) {
                    return Result.failure(IllegalStateException("Username @$trimmedUsername is already taken."))
                }
                if (currentProfile.usernameLowercase.isNotBlank()) {
                    batch.delete(db.collection("usernames").document(currentProfile.usernameLowercase))
                }
                if (!targetSnap.exists()) {
                    batch.set(
                        db.collection("usernames").document(newHandle),
                        mapOf(
                            "uid" to uid,
                            "username" to trimmedUsername,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }

            val updates = mutableMapOf<String, Any>(
                "displayName" to trimmedName,
                "displayNameLowercase" to trimmedName.lowercase(),
                "username" to trimmedUsername,
                "usernameLowercase" to newHandle,
                "bio" to bio.trim().take(300),
                "interests" to interests.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(15),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            photoUrl?.takeIf { it.isNotBlank() }?.let { updates["photoUrl"] = it }
            coverUrl?.takeIf { it.isNotBlank() }?.let { updates["coverUrl"] = it }

            batch.update(db.collection("users").document(uid), updates)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updatePrivacySettings(
        profileVisibility: ProfileVisibility,
        profileDiscoverable: Boolean,
        defaultPostVisibility: PostVisibility,
        allowUnknownMessages: Boolean
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val path = "users/$uid"
        return try {
            db.collection("users").document(uid).update(
                mapOf(
                    "profileVisibility" to profileVisibility.name,
                    "profileDiscoverable" to (profileDiscoverable && profileVisibility != ProfileVisibility.PRIVATE),
                    "defaultPostVisibility" to defaultPostVisibility.name,
                    "allowUnknownMessages" to allowUnknownMessages,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateNotificationPreferences(
        notifyFriendRequests: Boolean,
        notifyMessages: Boolean,
        notifyPostActivity: Boolean
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val path = "users/$uid/private/account"
        return try {
            db.collection("users").document(uid).collection("private").document("account")
                .update(
                    mapOf(
                        "notifyFriendRequests" to notifyFriendRequests,
                        "notifyMessages" to notifyMessages,
                        "notifyPostActivity" to notifyPostActivity,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun syncConnectionCount(uid: String, count: Long): Result<Unit> {
        val path = "users/$uid"
        return try {
            if (auth.currentUser?.uid != uid) return Result.success(Unit)
            db.collection("users").document(uid).update(
                mapOf(
                    "connectionCount" to count.coerceAtLeast(0L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun blockUser(target: UserProfile): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        if (target.uid == uid) return Result.failure(IllegalArgumentException("Cannot block yourself."))
        val blockId = "${uid}__${target.uid}"
        val path = "userBlocks/$blockId"
        return try {
            val batch = db.batch()
            batch.set(
                db.collection("userBlocks").document(blockId),
                mapOf(
                    "blockerId" to uid,
                    "blockedId" to target.uid,
                    "blockedName" to target.displayName.ifBlank { "Member" }.take(80),
                    "blockedUsername" to target.username.ifBlank { "user" }.take(30),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            // Also remove friendship if connected
            val friendshipId = deterministicPairId(uid, target.uid)
            val friendshipRef = db.collection("friendships").document(friendshipId)
            val friendshipSnap = friendshipRef.get().await()
            if (friendshipSnap.exists()) {
                batch.delete(friendshipRef)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun unblockUser(blockedId: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val blockId = "${uid}__${blockedId}"
        val path = "userBlocks/$blockId"
        return try {
            db.collection("userBlocks").document(blockId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun submitReport(
        targetType: ReportTargetType,
        targetId: String,
        targetOwnerId: String,
        reason: String
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val trimmed = reason.trim().take(500)
        if (trimmed.isEmpty()) return Result.failure(IllegalArgumentException("Please enter a reason."))
        val docRef = db.collection("reports").document()
        return try {
            docRef.set(
                mapOf(
                    "reporterId" to uid,
                    "targetType" to targetType.name,
                    "targetId" to targetId,
                    "targetOwnerId" to targetOwnerId,
                    "reason" to trimmed,
                    "status" to "OPEN",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteAccountData(usernameLowercase: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val path = "users/$uid"
        return try {
            val batch = db.batch()
            val ownPosts = db.collection("posts").whereEqualTo("authorId", uid).get().await()
            ownPosts.documents.forEach { batch.delete(it.reference) }

            val ownFriendships = db.collection("friendships").whereArrayContains("memberIds", uid).get().await()
            ownFriendships.documents.forEach { batch.delete(it.reference) }

            val ownRequests = db.collection("friendRequests").whereArrayContains("memberIds", uid).get().await()
            ownRequests.documents.forEach { batch.delete(it.reference) }

            val ownBlocks = db.collection("userBlocks").whereEqualTo("blockerId", uid).get().await()
            ownBlocks.documents.forEach { batch.delete(it.reference) }

            val ownNotifications = db.collection("notifications").whereEqualTo("recipientId", uid).get().await()
            ownNotifications.documents.forEach { batch.delete(it.reference) }

            if (usernameLowercase.isNotBlank()) {
                batch.delete(db.collection("usernames").document(usernameLowercase))
            }
            batch.delete(db.collection("users").document(uid).collection("private").document("account"))
            batch.delete(db.collection("users").document(uid))
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }
}
