package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ThemePreference
import com.example.data.model.safeEnumValueOf
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.connectHubDataStore: DataStore<Preferences> by preferencesDataStore(name = "connecthub_prefs")

class AuthPreferencesRepository(private val context: Context) {
    private val themeKey = stringPreferencesKey("theme_preference")

    val themePreference: Flow<ThemePreference> = context.connectHubDataStore.data.map { prefs ->
        safeEnumValueOf(prefs[themeKey], ThemePreference.SYSTEM)
    }

    suspend fun setThemePreference(preference: ThemePreference) {
        context.connectHubDataStore.edit { prefs ->
            prefs[themeKey] = preference.name
        }
    }
}
