package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PersonRemove
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.FriendRequest
import com.example.data.model.FriendRequestStatus
import com.example.data.model.MediaItem
import com.example.data.model.Post
import com.example.data.model.PostComment
import com.example.data.model.PostVisibility
import com.example.data.model.ProfileVisibility
import com.example.data.model.ReportTargetType
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.safeEnumValueOf
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FullscreenMediaDialog
import com.example.ui.components.PostCard
import com.example.ui.components.ReportDialog
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatTimestamp
import com.example.viewmodel.ConnectHubViewModel
import kotlinx.coroutines.delay

private val PROFILE_INTEREST_OPTIONS = listOf(
    "Technology", "Design", "Photography", "Travel", "Music",
    "Fitness", "Books", "Gaming", "Cooking", "Startups", "Film", "Art"
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: ConnectHubViewModel,
    viewedUserId: String,
    currentUser: UserProfile,
    friendIds: Set<String>,
    friendRequests: List<FriendRequest>,
    feedState: UiState<List<Post>>,
    likedPostIds: Set<String>,
    comments: List<PostComment>,
    isBusy: Boolean,
    uploadProgress: Float?,
    onBack: (() -> Unit)?,
    onOpenConversation: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onAuthorClick: (String) -> Unit
) {
    val isSelf = viewedUserId == currentUser.uid

    var fetchedProfile by remember(viewedUserId) { mutableStateOf<UserProfile?>(null) }
    var isFetching by remember(viewedUserId) { mutableStateOf(!isSelf) }
    var fetchError by remember(viewedUserId) { mutableStateOf<String?>(null) }

    LaunchedEffect(viewedUserId, currentUser) {
        if (isSelf) {
            fetchedProfile = currentUser
            isFetching = false
            fetchError = null
        } else {
            isFetching = true
            fetchError = null
            viewModel.fetchProfileById(viewedUserId)
                .onSuccess { prof ->
                    fetchedProfile = prof
                    isFetching = false
                }
                .onFailure { err ->
                    fetchError = err.localizedMessage ?: "Profile unavailable"
                    isFetching = false
                }
        }
    }

    val profile = if (isSelf) currentUser else fetchedProfile

    var showEditSheet by remember { mutableStateOf(false) }
    var showSafetyMenu by remember { mutableStateOf(false) }
    var showBlockConfirm by remember { mutableStateOf(false) }
    var showRemoveFriendConfirm by remember { mutableStateOf(false) }
    var showReportProfile by remember { mutableStateOf(false) }

    var editingPost by remember { mutableStateOf<Post?>(null) }
    var commentingPost by remember { mutableStateOf<Post?>(null) }
    var reportingPost by remember { mutableStateOf<Post?>(null) }
    var activeMedia by remember { mutableStateOf<MediaItem?>(null) }

    if (isFetching) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .testTag("profile_loading"),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    if (profile == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("profile_unavailable")
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                }
            }
            EmptyStateCard(
                title = "Profile unavailable",
                subtitle = fetchError ?: "This profile is private or could not be loaded.",
                actionLabel = if (onBack != null) "Go Back" else null,
                onAction = onBack
            )
        }
        return
    }

    val isFriend = viewedUserId in friendIds
    val incomingRequest = remember(friendRequests, viewedUserId, currentUser.uid) {
        friendRequests.firstOrNull {
            it.status == FriendRequestStatus.PENDING.name &&
                it.senderId == viewedUserId &&
                it.receiverId == currentUser.uid
        }
    }
    val sentRequest = remember(friendRequests, viewedUserId, currentUser.uid) {
        friendRequests.firstOrNull {
            it.status == FriendRequestStatus.PENDING.name &&
                it.senderId == currentUser.uid &&
                it.receiverId == viewedUserId
        }
    }

    val profilePosts = remember(feedState, viewedUserId) {
        ((feedState as? UiState.Success)?.data ?: emptyList())
            .filter { it.authorId == viewedUserId }
    }

    val profileVisibility = safeEnumValueOf(profile.profileVisibility, ProfileVisibility.PUBLIC)
    val canViewFullDetails = isSelf || profileVisibility == ProfileVisibility.PUBLIC || isFriend

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                ) {
                    if (!profile.coverUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = profile.coverUrl,
                            contentDescription = "${profile.displayName} cover photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.img_default_cover),
                            contentDescription = "Default profile cover banner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.25f), Color.Transparent, Color.Black.copy(alpha = 0.35f))
                                )
                            )
                    )

                    if (onBack != null) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                                .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                                .testTag("profile_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Color.White)
                        }
                    }

                    if (!isSelf) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                        ) {
                            IconButton(
                                onClick = { showSafetyMenu = true },
                                modifier = Modifier
                                    .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                                    .testTag("profile_safety_menu_button")
                            ) {
                                Icon(Icons.Rounded.MoreVert, "Profile safety options", tint = Color.White)
                            }
                            DropdownMenu(
                                expanded = showSafetyMenu,
                                onDismissRequest = { showSafetyMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Report profile") },
                                    leadingIcon = { Icon(Icons.Rounded.Flag, null) },
                                    onClick = {
                                        showSafetyMenu = false
                                        showReportProfile = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Block ${profile.displayName}", color = MaterialTheme.colorScheme.error) },
                                    leadingIcon = { Icon(Icons.Rounded.Block, null, tint = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showSafetyMenu = false
                                        showBlockConfirm = true
                                    }
                                )
                            }
                        }
                    }
                }

                // Avatar overlapping cover
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Box(
                        modifier = Modifier
                            .offset(y = (-42).dp)
                            .border(4.dp, MaterialTheme.colorScheme.background, CircleShape)
                            .clip(CircleShape)
                    ) {
                        UserAvatar(
                            name = profile.displayName,
                            photoUrl = profile.photoUrl,
                            size = 88.dp
                        )
                    }

                    Row(
                        modifier = Modifier.padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (isSelf) {
                            OutlinedButton(
                                onClick = onOpenSettings,
                                modifier = Modifier.testTag("profile_settings_button")
                            ) {
                                Icon(Icons.Rounded.Settings, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Settings")
                            }
                            Button(
                                onClick = { showEditSheet = true },
                                modifier = Modifier.testTag("edit_profile_button")
                            ) {
                                Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Edit Profile")
                            }
                        } else {
                            when {
                                isFriend -> {
                                    Button(
                                        onClick = {
                                            viewModel.openOrStartChatWithFriend(profile) { convId ->
                                                onOpenConversation(convId)
                                            }
                                        },
                                        modifier = Modifier.testTag("profile_message_button")
                                    ) {
                                        Icon(Icons.Rounded.ChatBubble, null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Message")
                                    }
                                    OutlinedButton(
                                        onClick = { showRemoveFriendConfirm = true },
                                        modifier = Modifier.testTag("profile_remove_friend_button")
                                    ) {
                                        Icon(Icons.Rounded.PersonRemove, null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Friends")
                                    }
                                }
                                incomingRequest != null -> {
                                    Button(
                                        onClick = { viewModel.acceptFriendRequest(incomingRequest) },
                                        modifier = Modifier.testTag("profile_accept_request_button")
                                    ) {
                                        Text("Accept Request")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.rejectFriendRequest(incomingRequest.id) }
                                    ) {
                                        Text("Decline")
                                    }
                                }
                                sentRequest != null -> {
                                    OutlinedButton(
                                        onClick = { viewModel.cancelFriendRequest(sentRequest.id) },
                                        modifier = Modifier.testTag("profile_cancel_request_button")
                                    ) {
                                        Text("Cancel Request")
                                    }
                                }
                                else -> {
                                    Button(
                                        onClick = { viewModel.sendFriendRequest(profile) },
                                        modifier = Modifier.testTag("profile_add_friend_button")
                                    ) {
                                        Icon(Icons.Rounded.PersonAdd, null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Add Friend")
                                    }
                                }
                            }
                        }
                    }
                }

                // Identity & Bio
                Column(
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .offset(y = (-24).dp)
                ) {
                    Text(
                        text = profile.displayName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "@${profile.username}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Icon(
                            imageVector = when (profileVisibility) {
                                ProfileVisibility.PUBLIC -> Icons.Rounded.Public
                                ProfileVisibility.FRIENDS_ONLY -> Icons.Rounded.Group
                                ProfileVisibility.PRIVATE -> Icons.Rounded.Lock
                            },
                            contentDescription = profileVisibility.label,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = profileVisibility.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(
                            text = "${profile.connectionCount} connections",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "${profilePosts.size} visible posts",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (canViewFullDetails) {
                        if (profile.bio.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = profile.bio,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        if (profile.interests.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                profile.interests.forEach { interest ->
                                    AssistChip(
                                        onClick = {},
                                        label = { Text(interest) }
                                    )
                                }
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "This profile is set to Friends Only. Connect as friends to view full bio, interests, and friend posts.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
            Text(
                text = "Posts",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        if (profilePosts.isEmpty()) {
            item {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    EmptyStateCard(
                        title = "No posts to display",
                        subtitle = if (isSelf) "Posts you publish on Home appear right here on your profile."
                        else "This user hasn't shared any posts visible to you yet."
                    )
                }
            }
        } else {
            items(profilePosts, key = { it.id }) { post ->
                LaunchedEffect(post.id) {
                    viewModel.refreshLikeStatus(post.id)
                }
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    PostCard(
                        post = post,
                        currentUserId = currentUser.uid,
                        isLiked = post.id in likedPostIds,
                        onAuthorClick = onAuthorClick,
                        onLikeClick = { viewModel.toggleLike(post) },
                        onCommentClick = {
                            commentingPost = post
                            viewModel.openComments(post)
                        },
                        onShareClick = { viewModel.sharePost(post) },
                        onEditClick = { editingPost = post },
                        onDeleteClick = { viewModel.deletePost(post.id) },
                        onReportClick = { reportingPost = post },
                        onMediaClick = { activeMedia = it }
                    )
                }
            }
        }
    }

    if (showEditSheet && isSelf) {
        EditProfileModal(
            currentProfile = currentUser,
            viewModel = viewModel,
            isBusy = isBusy,
            uploadProgress = uploadProgress,
            onDismiss = { showEditSheet = false }
        )
    }

    editingPost?.let { post ->
        ProfileEditPostDialog(
            post = post,
            onDismiss = { editingPost = null },
            onSave = { newText, newVis ->
                viewModel.editPost(post, newText, newVis) { editingPost = null }
            }
        )
    }

    commentingPost?.let { post ->
        ProfileCommentsSheet(
            post = post,
            comments = comments,
            onDismiss = {
                commentingPost = null
                viewModel.openComments(null)
            },
            onSendComment = { text, onDone -> viewModel.addComment(post, text, onDone) },
            onAuthorClick = onAuthorClick
        )
    }

    reportingPost?.let { post ->
        ReportDialog(
            title = "Report post by ${post.authorName}",
            onDismiss = { reportingPost = null },
            onSubmit = { reason ->
                viewModel.submitReport(ReportTargetType.POST, post.id, post.authorId, reason)
                reportingPost = null
            }
        )
    }

    if (showReportProfile) {
        ReportDialog(
            title = "Report ${profile.displayName}",
            onDismiss = { showReportProfile = false },
            onSubmit = { reason ->
                viewModel.submitReport(ReportTargetType.PROFILE, profile.uid, profile.uid, reason)
                showReportProfile = false
            }
        )
    }

    if (showBlockConfirm) {
        AlertDialog(
            onDismissRequest = { showBlockConfirm = false },
            title = { Text("Block ${profile.displayName}?") },
            text = { Text("Blocking hides their profile, posts, and messages, and removes any existing friendship.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.blockUser(profile) {
                            showBlockConfirm = false
                            onBack?.invoke()
                        }
                    }
                ) {
                    Text("Block", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBlockConfirm = false }) { Text("Cancel") }
            }
        )
    }

    if (showRemoveFriendConfirm) {
        AlertDialog(
            onDismissRequest = { showRemoveFriendConfirm = false },
            title = { Text("Remove ${profile.displayName}?") },
            text = { Text("You can send a friend request again later if you change your mind.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.removeFriend(profile.uid)
                        showRemoveFriendConfirm = false
                    }
                ) {
                    Text("Remove", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRemoveFriendConfirm = false }) { Text("Keep") }
            }
        )
    }

    FullscreenMediaDialog(media = activeMedia, onDismiss = { activeMedia = null })
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun EditProfileModal(
    currentProfile: UserProfile,
    viewModel: ConnectHubViewModel,
    isBusy: Boolean,
    uploadProgress: Float?,
    onDismiss: () -> Unit
) {
    var displayName by remember { mutableStateOf(currentProfile.displayName) }
    var username by remember { mutableStateOf(currentProfile.username) }
    var bio by remember { mutableStateOf(currentProfile.bio) }
    var selectedInterests by remember { mutableStateOf(currentProfile.interests.toSet()) }
    var newPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var newCoverUri by remember { mutableStateOf<Uri?>(null) }

    var usernameAvailable by remember { mutableStateOf<Boolean?>(true) }
    var checkingUsername by remember { mutableStateOf(false) }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) newPhotoUri = uri }
    )
    val coverPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) newCoverUri = uri }
    )

    LaunchedEffect(username) {
        val cleaned = username.trim()
        if (cleaned.equals(currentProfile.username, ignoreCase = true)) {
            usernameAvailable = true
            return@LaunchedEffect
        }
        if (!cleaned.matches(Regex("^[a-zA-Z0-9_]{3,30}$"))) {
            usernameAvailable = null
            return@LaunchedEffect
        }
        checkingUsername = true
        delay(350)
        usernameAvailable = viewModel.checkUsernameAvailable(cleaned).getOrNull()
        checkingUsername = false
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Text("Edit Profile", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(14.dp))

            // Cover Preview + Change
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .clickable {
                        coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    .testTag("edit_cover_picker")
            ) {
                when {
                    newCoverUri != null -> AsyncImage(
                        model = newCoverUri,
                        contentDescription = "New cover photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    !currentProfile.coverUrl.isNullOrBlank() -> AsyncImage(
                        model = currentProfile.coverUrl,
                        contentDescription = "Current cover photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    else -> Image(
                        painter = painterResource(id = R.drawable.img_default_cover),
                        contentDescription = "Default cover photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.AddAPhoto, null, tint = Color.White, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Change Cover", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .clickable {
                            avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }
                        .testTag("edit_avatar_picker"),
                    contentAlignment = Alignment.Center
                ) {
                    if (newPhotoUri != null) {
                        AsyncImage(
                            model = newPhotoUri,
                            contentDescription = "New avatar",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        UserAvatar(
                            name = currentProfile.displayName,
                            photoUrl = currentProfile.photoUrl,
                            size = 68.dp
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                OutlinedButton(
                    onClick = {
                        avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                ) {
                    Text("Change Avatar")
                }
            }

            if (uploadProgress != null) {
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(progress = { uploadProgress }, modifier = Modifier.fillMaxWidth())
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = displayName,
                onValueChange = { displayName = it.take(80) },
                label = { Text("Full Name") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edit_fullname_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = username,
                onValueChange = { username = it.filter { ch -> ch.isLetterOrDigit() || ch == '_' }.take(30) },
                label = { Text("Username") },
                prefix = { Text("@") },
                singleLine = true,
                trailingIcon = {
                    when {
                        checkingUsername -> CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        usernameAvailable == true -> Icon(Icons.Rounded.CheckCircle, "Available", tint = MaterialTheme.colorScheme.tertiary)
                        usernameAvailable == false -> Icon(Icons.Rounded.ErrorOutline, "Taken", tint = MaterialTheme.colorScheme.error)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edit_username_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it.take(300) },
                label = { Text("Bio") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edit_bio_input")
            )

            Spacer(modifier = Modifier.height(12.dp))
            Text("Interests", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PROFILE_INTEREST_OPTIONS.forEach { interest ->
                    val selected = interest in selectedInterests
                    FilterChip(
                        selected = selected,
                        onClick = {
                            selectedInterests = if (selected) selectedInterests - interest else selectedInterests + interest
                        },
                        label = { Text(interest) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) { Text("Cancel") }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        viewModel.updateProfile(
                            currentProfile = currentProfile,
                            displayName = displayName,
                            username = username,
                            bio = bio,
                            interests = selectedInterests.toList(),
                            newPhotoUri = newPhotoUri,
                            newCoverUri = newCoverUri,
                            onDone = onDismiss
                        )
                    },
                    enabled = !isBusy && displayName.isNotBlank() && username.length >= 3 && usernameAvailable != false,
                    modifier = Modifier.testTag("save_profile_button")
                ) {
                    if (isBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Text("Save Changes")
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun ProfileEditPostDialog(
    post: Post,
    onDismiss: () -> Unit,
    onSave: (String, PostVisibility) -> Unit
) {
    var text by remember { mutableStateOf(post.text) }
    var visibility by remember { mutableStateOf(safeEnumValueOf(post.visibility, PostVisibility.FRIENDS)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Post") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(2000) },
                    label = { Text("Post text") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PostVisibility.entries.forEach { vis ->
                        FilterChip(
                            selected = visibility == vis,
                            onClick = { visibility = vis },
                            label = { Text(vis.label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(text, visibility) },
                enabled = text.isNotBlank() || post.media.isNotEmpty()
            ) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileCommentsSheet(
    post: Post,
    comments: List<PostComment>,
    onDismiss: () -> Unit,
    onSendComment: (String, () -> Unit) -> Unit,
    onAuthorClick: (String) -> Unit
) {
    var draft by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Text("Comments (${post.commentCount})", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (comments.isEmpty()) {
                    item {
                        Text(
                            text = "No comments yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                } else {
                    items(comments, key = { it.id }) { comment ->
                        Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth()) {
                            UserAvatar(
                                name = comment.authorName,
                                photoUrl = comment.authorPhotoUrl,
                                size = 34.dp,
                                modifier = Modifier.clickable { onAuthorClick(comment.authorId) }
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(comment.authorName, style = MaterialTheme.typography.labelLarge)
                                        Text(
                                            formatTimestamp(comment.createdAt),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(comment.text, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it.take(1000) },
                    placeholder = { Text("Write a comment...") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val trimmed = draft.trim()
                        if (trimmed.isNotEmpty()) onSendComment(trimmed) { draft = "" }
                    },
                    enabled = draft.isNotBlank()
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Send, "Send comment", tint = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
