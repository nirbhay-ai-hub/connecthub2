package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.CloudQueue
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.data.model.PostVisibility
import com.example.data.model.PrivateAccount
import com.example.data.model.ProfileVisibility
import com.example.data.model.ThemePreference
import com.example.data.model.UserBlock
import com.example.data.model.UserProfile
import com.example.data.model.safeEnumValueOf
import com.example.ui.auth.signOut
import com.example.ui.components.UserAvatar
import com.example.viewmodel.ConnectHubViewModel

@Composable
fun SettingsScreen(
    viewModel: ConnectHubViewModel,
    currentUser: UserProfile,
    privateAccount: PrivateAccount?,
    blockedUsers: List<UserBlock>,
    themePreference: ThemePreference,
    isBusy: Boolean,
    onEditProfile: () -> Unit,
    onSignedOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var profileVisibility by remember(currentUser.profileVisibility) {
        mutableStateOf(safeEnumValueOf(currentUser.profileVisibility, ProfileVisibility.PUBLIC))
    }
    var discoverable by remember(currentUser.profileDiscoverable) {
        mutableStateOf(currentUser.profileDiscoverable)
    }
    var defaultPostVis by remember(currentUser.defaultPostVisibility) {
        mutableStateOf(safeEnumValueOf(currentUser.defaultPostVisibility, PostVisibility.FRIENDS))
    }
    var allowUnknownMessages by remember(currentUser.allowUnknownMessages) {
        mutableStateOf(currentUser.allowUnknownMessages)
    }

    var notifyFriendReqs by remember(privateAccount?.notifyFriendRequests) {
        mutableStateOf(privateAccount?.notifyFriendRequests ?: true)
    }
    var notifyMessages by remember(privateAccount?.notifyMessages) {
        mutableStateOf(privateAccount?.notifyMessages ?: true)
    }
    var notifyPostActivity by remember(privateAccount?.notifyPostActivity) {
        mutableStateOf(privateAccount?.notifyPostActivity ?: true)
    }

    LaunchedEffect(privateAccount) {
        if (privateAccount != null) {
            notifyFriendReqs = privateAccount.notifyFriendRequests
            notifyMessages = privateAccount.notifyMessages
            notifyPostActivity = privateAccount.notifyPostActivity
        }
    }

    var showDeleteConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(name = currentUser.displayName, photoUrl = currentUser.photoUrl, size = 56.dp)
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(currentUser.displayName, style = MaterialTheme.typography.titleMedium)
                        Text("@${currentUser.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val accountEmail = privateAccount?.email
                        if (!accountEmail.isNullOrBlank()) {
                            Text(
                                text = "Private email: $accountEmail",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = onEditProfile,
                        modifier = Modifier.testTag("settings_edit_profile_button")
                    ) {
                        Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Edit")
                    }
                }
            }
        }

        // Theme
        item {
            SettingsSectionCard(icon = Icons.Rounded.Palette, title = "Appearance") {
                Text(
                    "Choose light, dark, or match your device theme.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemePreference.entries.forEach { pref ->
                        FilterChip(
                            selected = themePreference == pref,
                            onClick = { viewModel.setThemePreference(pref) },
                            label = { Text(pref.label) },
                            modifier = Modifier.testTag("theme_chip_${pref.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // Privacy
        item {
            SettingsSectionCard(icon = Icons.Rounded.Shield, title = "Privacy & Discovery") {
                Text("Profile Visibility", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(6.dp))
                ProfileVisibility.entries.forEach { vis ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                profileVisibility = vis
                                if (vis == ProfileVisibility.PRIVATE) discoverable = false
                            }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = profileVisibility == vis,
                            onClick = {
                                profileVisibility = vis
                                if (vis == ProfileVisibility.PRIVATE) discoverable = false
                            }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(vis.label, style = MaterialTheme.typography.bodyMedium)
                            Text(vis.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(8.dp))

                SettingsSwitchRow(
                    title = "Discoverable in People You May Know",
                    subtitle = "Allow eligible ConnectHub members to discover and request you",
                    checked = discoverable && profileVisibility != ProfileVisibility.PRIVATE,
                    enabled = profileVisibility != ProfileVisibility.PRIVATE,
                    onCheckedChange = { discoverable = it },
                    testTag = "settings_discoverable_switch"
                )

                Spacer(modifier = Modifier.height(10.dp))
                Text("Default Post Audience", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PostVisibility.entries.forEach { vis ->
                        FilterChip(
                            selected = defaultPostVis == vis,
                            onClick = { defaultPostVis = vis },
                            label = { Text(vis.label) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                SettingsSwitchRow(
                    title = "Allow Message Requests Preference",
                    subtitle = "Note: Active 1-to-1 private chat requires an accepted friend connection",
                    checked = allowUnknownMessages,
                    enabled = true,
                    onCheckedChange = { allowUnknownMessages = it },
                    testTag = "settings_unknown_messages_switch"
                )

                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        viewModel.updatePrivacySettings(
                            visibility = profileVisibility,
                            discoverable = discoverable,
                            defaultPostVisibility = defaultPostVis,
                            allowUnknownMessages = allowUnknownMessages
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_privacy_button")
                ) {
                    Text("Save Privacy Settings")
                }
            }
        }

        // Notifications
        item {
            SettingsSectionCard(icon = Icons.Rounded.Notifications, title = "Notifications") {
                SettingsSwitchRow(
                    title = "Friend Requests & Acceptances",
                    subtitle = "Show in-app alerts when people connect with you",
                    checked = notifyFriendReqs,
                    enabled = true,
                    onCheckedChange = {
                        notifyFriendReqs = it
                        viewModel.updateNotificationPrefs(it, notifyMessages, notifyPostActivity)
                    },
                    testTag = "settings_notify_friends_switch"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                SettingsSwitchRow(
                    title = "Private Messages",
                    subtitle = "Alert when friends send new messages",
                    checked = notifyMessages,
                    enabled = true,
                    onCheckedChange = {
                        notifyMessages = it
                        viewModel.updateNotificationPrefs(notifyFriendReqs, it, notifyPostActivity)
                    },
                    testTag = "settings_notify_messages_switch"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                SettingsSwitchRow(
                    title = "Post Likes & Comments",
                    subtitle = "Alert when members interact with your posts",
                    checked = notifyPostActivity,
                    enabled = true,
                    onCheckedChange = {
                        notifyPostActivity = it
                        viewModel.updateNotificationPrefs(notifyFriendReqs, notifyMessages, it)
                    },
                    testTag = "settings_notify_posts_switch"
                )
            }
        }

        // Blocked Users
        item {
            SettingsSectionCard(icon = Icons.Rounded.Block, title = "Blocked Users (${blockedUsers.size})") {
                if (blockedUsers.isEmpty()) {
                    Text(
                        "You haven't blocked any accounts.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        blockedUsers.forEach { block ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(block.blockedName, style = MaterialTheme.typography.titleSmall)
                                    Text("@${block.blockedUsername}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                OutlinedButton(
                                    onClick = { viewModel.unblockUser(block.blockedId) },
                                    modifier = Modifier.testTag("unblock_${block.blockedId}")
                                ) {
                                    Text("Unblock")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Firebase Console Info
        item {
            SettingsSectionCard(icon = Icons.Rounded.CloudQueue, title = "Firebase Backend Status") {
                Text(
                    "Cloud Firestore and Google Sign-In are active. If media uploads fail with a bucket or permission error, ensure Firebase Storage is initialized in the Firebase Console and deploy storage.rules.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Account Actions
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        signOut(credentialManager, scope) {
                            onSignedOut()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("sign_out_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Logout, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sign Out")
                }

                Button(
                    onClick = { showDeleteConfirm = true },
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("delete_account_button")
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(Modifier.size(18.dp), color = MaterialTheme.colorScheme.onError, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Rounded.DeleteForever, null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Delete Account Data")
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete ConnectHub Account?") },
            text = {
                Text("This permanently deletes your ConnectHub profile, posts, friendships, blocks, notifications, and frees your @${currentUser.username} handle, then signs you out.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        viewModel.deleteAccount {
                            signOut(credentialManager, scope) {
                                onSignedOut()
                            }
                        }
                    }
                ) {
                    Text("Delete Forever", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    icon: ImageVector,
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            modifier = Modifier.testTag(testTag)
        )
    }
}
