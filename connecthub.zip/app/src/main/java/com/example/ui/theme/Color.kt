package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ConnectHub Brand Palette — Daylight & Midnight Slate
val CoralPrimary = Color(0xFFFF5A36)
val CoralOnPrimary = Color(0xFFFFFFFF)
val CoralContainer = Color(0xFFFFE5DF)
val CoralOnContainer = Color(0xFF410E00)

val IndigoSecondary = Color(0xFF4F46E5)
val IndigoOnSecondary = Color(0xFFFFFFFF)
val IndigoContainer = Color(0xFFE0E7FF)
val IndigoOnContainer = Color(0xFF1E1B4B)

val TealTertiary = Color(0xFF0D9488)
val TealOnTertiary = Color(0xFFFFFFFF)
val TealContainer = Color(0xFFCCFBF1)
val TealOnContainer = Color(0xFF042F2E)

val LightBackground = Color(0xFFFAF9F6)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFE2E8F0)

// Dark Theme Tokens
val CoralPrimaryDark = Color(0xFFFF8A70)
val CoralOnPrimaryDark = Color(0xFF561500)
val CoralContainerDark = Color(0xFF7A2107)
val CoralOnContainerDark = Color(0xFFFFDAD2)

val IndigoSecondaryDark = Color(0xFFA5B4FC)
val IndigoOnSecondaryDark = Color(0xFF1E1B4B)
val IndigoContainerDark = Color(0xFF312E81)
val IndigoOnContainerDark = Color(0xFFE0E7FF)

val TealTertiaryDark = Color(0xFF5EEAD4)
val TealOnTertiaryDark = Color(0xFF003832)
val TealContainerDark = Color(0xFF115E59)
val TealOnContainerDark = Color(0xFFCCFBF1)

val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF283548)

val EmeraldOnline = Color(0xFF10B981)
val RoseAlert = Color(0xFFE11D48)
