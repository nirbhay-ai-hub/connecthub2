package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.config.MediaConfig
import com.example.data.model.MediaItem
import com.example.data.model.Post
import com.example.data.model.PostComment
import com.example.data.model.PostVisibility
import com.example.data.model.ReportTargetType
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.safeEnumValueOf
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FullscreenMediaDialog
import com.example.ui.components.PostCard
import com.example.ui.components.ReportDialog
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatTimestamp
import com.example.viewmodel.ConnectHubViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeFeedScreen(
    viewModel: ConnectHubViewModel,
    currentUser: UserProfile,
    feedState: UiState<List<Post>>,
    likedPostIds: Set<String>,
    comments: List<PostComment>,
    isBusy: Boolean,
    uploadProgress: Float?,
    onNavigateToUser: (String) -> Unit,
    onNavigateToExplore: () -> Unit
) {
    var showComposer by remember { mutableStateOf(false) }
    var editingPost by remember { mutableStateOf<Post?>(null) }
    var commentingPost by remember { mutableStateOf<Post?>(null) }
    var reportingPost by remember { mutableStateOf<Post?>(null) }
    var activeMedia by remember { mutableStateOf<MediaItem?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_feed_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showComposer = true }
                    .testTag("open_post_composer_card")
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(name = currentUser.displayName, photoUrl = currentUser.photoUrl, size = 42.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Share what's on your mind, ${currentUser.displayName.substringBefore(" ")}...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { showComposer = true },
                        modifier = Modifier.testTag("create_post_icon_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Create,
                            contentDescription = "Create post",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        when (feedState) {
            is UiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> {
                item {
                    EmptyStateCard(
                        title = "Couldn't load your feed",
                        subtitle = feedState.message
                    )
                }
            }
            is UiState.Success -> {
                val posts = feedState.data
                if (posts.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "Your ConnectHub feed is quiet",
                            subtitle = "Publish your first post or discover people to connect with on Explore.",
                            actionLabel = "Discover People",
                            onAction = onNavigateToExplore
                        )
                    }
                } else {
                    items(posts, key = { it.id }) { post ->
                        LaunchedEffect(post.id) {
                            viewModel.refreshLikeStatus(post.id)
                        }
                        PostCard(
                            post = post,
                            currentUserId = currentUser.uid,
                            isLiked = post.id in likedPostIds,
                            onAuthorClick = onNavigateToUser,
                            onLikeClick = { viewModel.toggleLike(post) },
                            onCommentClick = {
                                commentingPost = post
                                viewModel.openComments(post)
                            },
                            onShareClick = { viewModel.sharePost(post) },
                            onEditClick = { editingPost = post },
                            onDeleteClick = { viewModel.deletePost(post.id) },
                            onReportClick = { reportingPost = post },
                            onMediaClick = { activeMedia = it }
                        )
                    }
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.loadMoreFeed() },
                                modifier = Modifier.testTag("load_more_posts_button")
                            ) {
                                Text("Load more posts")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showComposer) {
        CreatePostSheet(
            defaultVisibility = safeEnumValueOf(currentUser.defaultPostVisibility, PostVisibility.FRIENDS),
            isBusy = isBusy,
            uploadProgress = uploadProgress,
            onDismiss = { showComposer = false },
            onPublish = { text, uris, vis ->
                viewModel.createPost(text, uris, vis) {
                    showComposer = false
                }
            }
        )
    }

    editingPost?.let { post ->
        EditPostDialog(
            post = post,
            onDismiss = { editingPost = null },
            onSave = { newText, newVis ->
                viewModel.editPost(post, newText, newVis) {
                    editingPost = null
                }
            }
        )
    }

    commentingPost?.let { post ->
        CommentsBottomSheet(
            post = post,
            comments = comments,
            onDismiss = {
                commentingPost = null
                viewModel.openComments(null)
            },
            onSendComment = { text, onDone ->
                viewModel.addComment(post, text, onDone)
            },
            onAuthorClick = onNavigateToUser
        )
    }

    reportingPost?.let { post ->
        ReportDialog(
            title = "Report post by ${post.authorName}",
            onDismiss = { reportingPost = null },
            onSubmit = { reason ->
                viewModel.submitReport(ReportTargetType.POST, post.id, post.authorId, reason)
                reportingPost = null
            }
        )
    }

    FullscreenMediaDialog(media = activeMedia, onDismiss = { activeMedia = null })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreatePostSheet(
    defaultVisibility: PostVisibility,
    isBusy: Boolean,
    uploadProgress: Float?,
    onDismiss: () -> Unit,
    onPublish: (String, List<Uri>, PostVisibility) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var selectedUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var visibility by remember { mutableStateOf(defaultVisibility) }

    val mediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(MediaConfig.MAX_POST_ATTACHMENTS),
        onResult = { uris ->
            if (uris.isNotEmpty()) {
                selectedUris = (selectedUris + uris).distinct().take(MediaConfig.MAX_POST_ATTACHMENTS)
            }
        }
    )

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text("Create Post", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(2000) },
                label = { Text("What's new?") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_text_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text("Audience", style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PostVisibility.entries.forEach { vis ->
                    FilterChip(
                        selected = visibility == vis,
                        onClick = { visibility = vis },
                        leadingIcon = {
                            Icon(
                                imageVector = when (vis) {
                                    PostVisibility.PUBLIC -> Icons.Rounded.Public
                                    PostVisibility.FRIENDS -> Icons.Rounded.Group
                                    PostVisibility.PRIVATE -> Icons.Rounded.Lock
                                },
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(vis.label) }
                    )
                }
            }

            if (selectedUris.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    selectedUris.forEach { uri ->
                        Box(modifier = Modifier.size(84.dp)) {
                            AsyncImage(
                                model = uri,
                                contentDescription = "Selected media preview",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(MaterialTheme.shapes.small)
                            )
                            IconButton(
                                onClick = { selectedUris = selectedUris - uri },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(24.dp)
                                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f), CircleShape)
                            ) {
                                Icon(Icons.Rounded.Close, "Remove", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            if (uploadProgress != null) {
                Spacer(modifier = Modifier.height(10.dp))
                LinearProgressIndicator(progress = { uploadProgress }, modifier = Modifier.fillMaxWidth())
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    },
                    modifier = Modifier.testTag("add_post_media_button")
                ) {
                    Icon(Icons.Rounded.AddPhotoAlternate, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Photo / Video (${selectedUris.size}/${MediaConfig.MAX_POST_ATTACHMENTS})")
                }

                Button(
                    onClick = { onPublish(text, selectedUris, visibility) },
                    enabled = !isBusy && (text.isNotBlank() || selectedUris.isNotEmpty()),
                    modifier = Modifier.testTag("publish_post_button")
                ) {
                    if (isBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Text("Publish")
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun EditPostDialog(
    post: Post,
    onDismiss: () -> Unit,
    onSave: (String, PostVisibility) -> Unit
) {
    var text by remember { mutableStateOf(post.text) }
    var visibility by remember {
        mutableStateOf(safeEnumValueOf(post.visibility, PostVisibility.FRIENDS))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Post") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(2000) },
                    label = { Text("Post text") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PostVisibility.entries.forEach { vis ->
                        FilterChip(
                            selected = visibility == vis,
                            onClick = { visibility = vis },
                            label = { Text(vis.label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(text, visibility) },
                enabled = text.isNotBlank() || post.media.isNotEmpty()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CommentsBottomSheet(
    post: Post,
    comments: List<PostComment>,
    onDismiss: () -> Unit,
    onSendComment: (String, () -> Unit) -> Unit,
    onAuthorClick: (String) -> Unit
) {
    var draft by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Text("Comments (${post.commentCount})", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 340.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (comments.isEmpty()) {
                    item {
                        Text(
                            text = "No comments yet. Start the conversation!",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    }
                } else {
                    items(comments, key = { it.id }) { comment ->
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            UserAvatar(
                                name = comment.authorName,
                                photoUrl = comment.authorPhotoUrl,
                                size = 34.dp,
                                modifier = Modifier.clickable { onAuthorClick(comment.authorId) }
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(comment.authorName, style = MaterialTheme.typography.labelLarge)
                                        Text(
                                            formatTimestamp(comment.createdAt),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(comment.text, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it.take(1000) },
                    placeholder = { Text("Write a comment...") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("comment_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val trimmed = draft.trim()
                        if (trimmed.isNotEmpty()) {
                            onSendComment(trimmed) { draft = "" }
                        }
                    },
                    enabled = draft.isNotBlank(),
                    modifier = Modifier.testTag("send_comment_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Send, "Send comment", tint = MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
