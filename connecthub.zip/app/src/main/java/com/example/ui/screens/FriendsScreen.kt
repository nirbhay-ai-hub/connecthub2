package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PersonRemove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.FriendRequest
import com.example.data.model.FriendRequestStatus
import com.example.data.model.Friendship
import com.example.data.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.UserAvatar
import com.example.viewmodel.ConnectHubViewModel

@Composable
fun FriendsScreen(
    viewModel: ConnectHubViewModel,
    currentUser: UserProfile,
    friendships: List<Friendship>,
    friendRequests: List<FriendRequest>,
    discoverableUsers: List<UserProfile>,
    onViewProfile: (String) -> Unit,
    onOpenConversation: (String) -> Unit,
    onNavigateToExplore: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var friendToRemove by remember { mutableStateOf<UserProfile?>(null) }

    val fetchedFriendProfiles = remember { mutableStateMapOf<String, UserProfile>() }
    val discoverMap = remember(discoverableUsers) { discoverableUsers.associateBy { it.uid } }

    LaunchedEffect(friendships) {
        friendships.forEach { friendship ->
            val otherId = friendship.otherUserId(currentUser.uid)
            if (otherId !in discoverMap && otherId !in fetchedFriendProfiles) {
                viewModel.fetchProfileById(otherId).getOrNull()?.let { prof ->
                    fetchedFriendProfiles[otherId] = prof
                }
            }
        }
    }

    val incomingRequests = remember(friendRequests, currentUser.uid) {
        friendRequests.filter {
            it.status == FriendRequestStatus.PENDING.name && it.receiverId == currentUser.uid
        }
    }
    val sentRequests = remember(friendRequests, currentUser.uid) {
        friendRequests.filter {
            it.status == FriendRequestStatus.PENDING.name && it.senderId == currentUser.uid
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("friends_screen")
    ) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Friends (${friendships.size})") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Requests (${incomingRequests.size})") }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Sent (${sentRequests.size})") }
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    if (friendships.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "No friends connected yet",
                                subtitle = "Send friend requests on Explore to start connecting and chatting.",
                                actionLabel = "Find Friends",
                                onAction = onNavigateToExplore
                            )
                        }
                    } else {
                        items(friendships, key = { it.id }) { friendship ->
                            val friendId = friendship.otherUserId(currentUser.uid)
                            val profile = discoverMap[friendId] ?: fetchedFriendProfiles[friendId] ?: UserProfile(
                                uid = friendId,
                                displayName = "ConnectHub Friend",
                                username = friendId.take(8)
                            )
                            Card(
                                shape = MaterialTheme.shapes.large,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onViewProfile(friendId) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserAvatar(name = profile.displayName, photoUrl = profile.photoUrl, size = 48.dp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(profile.displayName, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            "@${profile.username} • ${profile.connectionCount} connections",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.openOrStartChatWithFriend(profile) { convId ->
                                                onOpenConversation(convId)
                                            }
                                        },
                                        modifier = Modifier.testTag("message_friend_${profile.uid}")
                                    ) {
                                        Icon(Icons.Rounded.ChatBubble, "Message", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(
                                        onClick = { friendToRemove = profile },
                                        modifier = Modifier.testTag("remove_friend_${profile.uid}")
                                    ) {
                                        Icon(Icons.Rounded.PersonRemove, "Remove friend", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    if (incomingRequests.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "No pending requests",
                                subtitle = "Incoming friend requests will show up here for your approval."
                            )
                        }
                    } else {
                        items(incomingRequests, key = { it.id }) { req ->
                            Card(
                                shape = MaterialTheme.shapes.large,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onViewProfile(req.senderId) }
                                    ) {
                                        UserAvatar(name = req.senderName, photoUrl = req.senderPhotoUrl, size = 46.dp)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(req.senderName, style = MaterialTheme.typography.titleSmall)
                                            Text("@${req.senderUsername}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Button(
                                            onClick = { viewModel.acceptFriendRequest(req) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("accept_request_${req.id}")
                                        ) {
                                            Icon(Icons.Rounded.Check, null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Accept")
                                        }
                                        OutlinedButton(
                                            onClick = { viewModel.rejectFriendRequest(req.id) },
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("reject_request_${req.id}")
                                        ) {
                                            Icon(Icons.Rounded.Close, null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Decline")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    if (sentRequests.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "No sent requests",
                                subtitle = "Friend requests you send to others appear here until accepted."
                            )
                        }
                    } else {
                        items(sentRequests, key = { it.id }) { req ->
                            Card(
                                shape = MaterialTheme.shapes.large,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    UserAvatar(name = req.receiverName, photoUrl = req.receiverPhotoUrl, size = 44.dp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(req.receiverName, style = MaterialTheme.typography.titleSmall)
                                        Text("@${req.receiverUsername}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.cancelFriendRequest(req.id) },
                                        modifier = Modifier.testTag("cancel_request_${req.id}")
                                    ) {
                                        Text("Cancel")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    friendToRemove?.let { target ->
        AlertDialog(
            onDismissRequest = { friendToRemove = null },
            title = { Text("Remove friend?") },
            text = { Text("Remove ${target.displayName} from your friends list? You can send a friend request again later.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.removeFriend(target.uid)
                        friendToRemove = null
                    }
                ) {
                    Text("Remove", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { friendToRemove = null }) { Text("Keep") }
            }
        )
    }
}
