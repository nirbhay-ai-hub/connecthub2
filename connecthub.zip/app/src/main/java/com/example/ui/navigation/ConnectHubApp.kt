package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.model.AppNotification
import com.example.data.model.FriendRequestStatus
import com.example.data.model.NotificationType
import com.example.data.model.SuggestedPerson
import com.example.data.model.ThemePreference
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.safeEnumValueOf
import com.example.data.repository.AuthPreferencesRepository
import com.example.data.repository.ChatRepository
import com.example.data.repository.MediaStorageRepository
import com.example.data.repository.NotificationRepository
import com.example.data.repository.ProfileRepository
import com.example.data.repository.SocialRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.ProfileSetupScreen
import com.example.ui.auth.signOut
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.UploadProgressBanner
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatTimestamp
import com.example.ui.screens.ExploreScreen
import com.example.ui.screens.FriendsScreen
import com.example.ui.screens.HomeFeedScreen
import com.example.ui.screens.MessagesScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ConnectHubTheme
import com.example.viewmodel.ConnectHubViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

enum class ConnectHubSection(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val route: String
) {
    HOME("Home", Icons.Rounded.Home, Icons.Outlined.Home, "home"),
    EXPLORE("Explore", Icons.Rounded.Explore, Icons.Outlined.Explore, "explore"),
    FRIENDS("Friends", Icons.Rounded.Group, Icons.Outlined.Group, "friends"),
    MESSAGES("Messages", Icons.Rounded.Forum, Icons.Outlined.Forum, "messages"),
    NOTIFICATIONS("Notifications", Icons.Rounded.Notifications, Icons.Outlined.Notifications, "notifications"),
    PROFILE("Profile", Icons.Rounded.Person, Icons.Outlined.Person, "profile"),
    SETTINGS("Settings", Icons.Rounded.Settings, Icons.Outlined.Settings, "settings")
}

private val BOTTOM_BAR_SECTIONS = listOf(
    ConnectHubSection.HOME,
    ConnectHubSection.EXPLORE,
    ConnectHubSection.FRIENDS,
    ConnectHubSection.MESSAGES,
    ConnectHubSection.PROFILE
)

private fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    trySend(currentUser)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun ConnectHubApp() {
    val context = LocalContext.current
    val app = context.applicationContext
    val prefsRepo = remember(app) { AuthPreferencesRepository(app) }
    val globalThemePref by prefsRepo.themePreference.collectAsStateWithLifecycle(ThemePreference.SYSTEM)
    val authFlow = remember { Firebase.auth.authStateFlow() }
    val firebaseUser by authFlow.collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

    ConnectHubTheme(themePreference = globalThemePref) {
        val activeUser = firebaseUser
        if (activeUser == null) {
            AuthScreen(onAuthSuccess = {})
        } else {
            key(activeUser.uid) {
                AuthenticatedConnectHubShell(
                    uid = activeUser.uid,
                    prefsRepo = prefsRepo
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedConnectHubShell(
    uid: String,
    prefsRepo: AuthPreferencesRepository
) {
    val context = LocalContext.current
    val app = context.applicationContext
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: ConnectHubViewModel = viewModel(
        key = "connecthub_vm_$uid",
        factory = viewModelFactory {
            initializer {
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                ConnectHubViewModel(
                    currentUserId = uid,
                    profileRepo = ProfileRepository(db),
                    socialRepo = SocialRepository(db),
                    chatRepo = ChatRepository(db),
                    notificationRepo = NotificationRepository(db),
                    mediaRepo = MediaStorageRepository(app),
                    prefsRepo = prefsRepo
                )
            }
        }
    )

    val currentProfileState by viewModel.currentProfileState.collectAsStateWithLifecycle()
    val privateAccount by viewModel.privateAccount.collectAsStateWithLifecycle()
    val blockedUsers by viewModel.blockedUsers.collectAsStateWithLifecycle()
    val discoverableUsers by viewModel.discoverableUsers.collectAsStateWithLifecycle()
    val friendRequests by viewModel.friendRequests.collectAsStateWithLifecycle()
    val friendships by viewModel.friendships.collectAsStateWithLifecycle()
    val friendIds by viewModel.friendIds.collectAsStateWithLifecycle()
    val suggestions by viewModel.suggestions.collectAsStateWithLifecycle()
    val feedState by viewModel.feedState.collectAsStateWithLifecycle()
    val likedPostIds by viewModel.likedPostIds.collectAsStateWithLifecycle()
    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val activeMessages by viewModel.activeMessages.collectAsStateWithLifecycle()
    val activeComments by viewModel.activeComments.collectAsStateWithLifecycle()
    val uploadProgress by viewModel.uploadProgress.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    val themePreference by viewModel.themePreference.collectAsStateWithLifecycle()

    var currentSection by remember { mutableStateOf(ConnectHubSection.HOME) }
    var viewedProfileUserId by remember { mutableStateOf<String?>(null) }
    var selectedConversationId by remember { mutableStateOf<String?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(actionMessage) {
        val msg = actionMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearMessage()
    }

    when (val profileUi = currentProfileState) {
        is UiState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .windowInsetsPadding(WindowInsets.safeDrawing),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Loading ConnectHub...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        is UiState.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    EmptyStateCard(
                        title = "Couldn't connect to ConnectHub",
                        subtitle = profileUi.message,
                        actionLabel = "Sign Out",
                        onAction = { signOut(credentialManager, scope) }
                    )
                }
            }
        }

        is UiState.Success -> {
            val currentUser = profileUi.data
            if (currentUser == null) {
                ProfileSetupScreen(
                    viewModel = viewModel,
                    isBusy = isBusy,
                    uploadProgress = uploadProgress,
                    errorMessage = actionMessage,
                    onSignOut = { signOut(credentialManager, scope) }
                )
            } else {
                val pendingRequestsCount = remember(friendRequests, currentUser.uid) {
                    friendRequests.count {
                        it.status == FriendRequestStatus.PENDING.name && it.receiverId == currentUser.uid
                    }
                }
                val unreadMessagesCount = remember(conversations, currentUser.uid) {
                    conversations.sumOf { it.unreadFor(currentUser.uid).toInt() }
                }
                val unreadNotificationsCount = remember(notifications) {
                    notifications.count { !it.read }
                }

                // Sub-destination BackHandlers
                BackHandler(enabled = viewedProfileUserId != null) {
                    viewedProfileUserId = null
                }
                BackHandler(
                    enabled = viewedProfileUserId == null &&
                        currentSection != ConnectHubSection.HOME &&
                        !(currentSection == ConnectHubSection.MESSAGES && selectedConversationId != null)
                ) {
                    currentSection = ConnectHubSection.HOME
                }

                val navigateToProfile: (String) -> Unit = { targetId ->
                    if (targetId == currentUser.uid) {
                        viewedProfileUserId = null
                        currentSection = ConnectHubSection.PROFILE
                    } else {
                        viewedProfileUserId = targetId
                    }
                }

                val openConversation: (String) -> Unit = { convId ->
                    viewedProfileUserId = null
                    selectedConversationId = convId
                    viewModel.selectConversation(convId)
                    currentSection = ConnectHubSection.MESSAGES
                }

                val handleNotificationClick: (AppNotification) -> Unit = { notif ->
                    viewedProfileUserId = null
                    when (safeEnumValueOf(notif.type, NotificationType.LIKE)) {
                        NotificationType.FRIEND_REQUEST -> currentSection = ConnectHubSection.FRIENDS
                        NotificationType.FRIEND_ACCEPTED -> {
                            if (notif.actorId.isNotBlank()) viewedProfileUserId = notif.actorId
                            else currentSection = ConnectHubSection.FRIENDS
                        }
                        NotificationType.MESSAGE -> {
                            if (notif.targetId.isNotBlank()) openConversation(notif.targetId)
                            else currentSection = ConnectHubSection.MESSAGES
                        }
                        NotificationType.LIKE, NotificationType.COMMENT -> {
                            currentSection = ConnectHubSection.HOME
                        }
                    }
                }

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val isExpanded = maxWidth >= 840.dp
                    val showRightSidebar = maxWidth >= 1140.dp

                    Scaffold(
                        contentWindowInsets = WindowInsets.safeDrawing,
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = {
                            if (!isExpanded && viewedProfileUserId == null) {
                                TopAppBar(
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = MaterialTheme.colorScheme.surface
                                    ),
                                    title = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = MaterialTheme.colorScheme.primary,
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.size(30.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Icon(
                                                        Icons.Rounded.AutoAwesome,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onPrimary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = if (currentSection == ConnectHubSection.HOME) "ConnectHub" else currentSection.title,
                                                style = MaterialTheme.typography.titleLarge,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    },
                                    actions = {
                                        IconButton(
                                            onClick = { currentSection = ConnectHubSection.NOTIFICATIONS },
                                            modifier = Modifier.testTag("topbar_notifications_button")
                                        ) {
                                            BadgedBox(
                                                badge = {
                                                    if (unreadNotificationsCount > 0) {
                                                        Badge { Text("$unreadNotificationsCount") }
                                                    }
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = if (currentSection == ConnectHubSection.NOTIFICATIONS)
                                                        Icons.Rounded.Notifications else Icons.Outlined.Notifications,
                                                    contentDescription = "Notifications"
                                                )
                                            }
                                        }
                                        IconButton(
                                            onClick = { currentSection = ConnectHubSection.SETTINGS },
                                            modifier = Modifier.testTag("topbar_settings_button")
                                        ) {
                                            Icon(
                                                imageVector = if (currentSection == ConnectHubSection.SETTINGS)
                                                    Icons.Rounded.Settings else Icons.Outlined.Settings,
                                                contentDescription = "Settings"
                                            )
                                        }
                                    }
                                )
                            }
                        },
                        bottomBar = {
                            if (!isExpanded && viewedProfileUserId == null) {
                                NavigationBar {
                                    BOTTOM_BAR_SECTIONS.forEach { section ->
                                        val selected = currentSection == section
                                        val badgeCount = when (section) {
                                            ConnectHubSection.FRIENDS -> pendingRequestsCount
                                            ConnectHubSection.MESSAGES -> unreadMessagesCount
                                            else -> 0
                                        }
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = { currentSection = section },
                                            icon = {
                                                BadgedBox(
                                                    badge = {
                                                        if (badgeCount > 0) {
                                                            Badge { Text("$badgeCount") }
                                                        }
                                                    }
                                                ) {
                                                    Icon(
                                                        imageVector = if (selected) section.selectedIcon else section.unselectedIcon,
                                                        contentDescription = section.title
                                                    )
                                                }
                                            },
                                            label = {
                                                Text(
                                                    text = section.title,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            },
                                            modifier = Modifier.testTag("bottom_nav_${section.route}")
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            if (isExpanded) {
                                NavigationRail(
                                    header = {
                                        Surface(
                                            color = MaterialTheme.colorScheme.primary,
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier
                                                .padding(vertical = 8.dp)
                                                .size(44.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    Icons.Rounded.AutoAwesome,
                                                    contentDescription = "ConnectHub",
                                                    tint = MaterialTheme.colorScheme.onPrimary
                                                )
                                            }
                                        }
                                    },
                                    modifier = Modifier.testTag("desktop_navigation_rail")
                                ) {
                                    ConnectHubSection.entries.forEach { section ->
                                        val selected = viewedProfileUserId == null && currentSection == section
                                        val badgeCount = when (section) {
                                            ConnectHubSection.FRIENDS -> pendingRequestsCount
                                            ConnectHubSection.MESSAGES -> unreadMessagesCount
                                            ConnectHubSection.NOTIFICATIONS -> unreadNotificationsCount
                                            else -> 0
                                        }
                                        NavigationRailItem(
                                            selected = selected,
                                            onClick = {
                                                viewedProfileUserId = null
                                                currentSection = section
                                            },
                                            icon = {
                                                BadgedBox(
                                                    badge = {
                                                        if (badgeCount > 0) Badge { Text("$badgeCount") }
                                                    }
                                                ) {
                                                    Icon(
                                                        imageVector = if (selected) section.selectedIcon else section.unselectedIcon,
                                                        contentDescription = section.title
                                                    )
                                                }
                                            },
                                            label = { Text(section.title) },
                                            modifier = Modifier.testTag("rail_nav_${section.route}")
                                        )
                                    }
                                }
                                VerticalDivider()
                            }

                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                UploadProgressBanner(progress = uploadProgress)

                                val useFullWidth = currentSection == ConnectHubSection.MESSAGES && viewedProfileUserId == null
                                Box(
                                    modifier = if (useFullWidth) {
                                        Modifier.fillMaxSize()
                                    } else {
                                        Modifier
                                            .fillMaxHeight()
                                            .fillMaxWidth()
                                            .widthIn(max = 760.dp)
                                    }
                                ) {
                                    val targetProfileId = viewedProfileUserId
                                    if (targetProfileId != null) {
                                        ProfileScreen(
                                            viewModel = viewModel,
                                            viewedUserId = targetProfileId,
                                            currentUser = currentUser,
                                            friendIds = friendIds,
                                            friendRequests = friendRequests,
                                            feedState = feedState,
                                            likedPostIds = likedPostIds,
                                            comments = activeComments,
                                            isBusy = isBusy,
                                            uploadProgress = uploadProgress,
                                            onBack = { viewedProfileUserId = null },
                                            onOpenConversation = openConversation,
                                            onOpenSettings = {
                                                viewedProfileUserId = null
                                                currentSection = ConnectHubSection.SETTINGS
                                            },
                                            onAuthorClick = navigateToProfile
                                        )
                                    } else {
                                        when (currentSection) {
                                            ConnectHubSection.HOME -> HomeFeedScreen(
                                                viewModel = viewModel,
                                                currentUser = currentUser,
                                                feedState = feedState,
                                                likedPostIds = likedPostIds,
                                                comments = activeComments,
                                                isBusy = isBusy,
                                                uploadProgress = uploadProgress,
                                                onNavigateToUser = navigateToProfile,
                                                onNavigateToExplore = { currentSection = ConnectHubSection.EXPLORE }
                                            )

                                            ConnectHubSection.EXPLORE -> ExploreScreen(
                                                viewModel = viewModel,
                                                currentUser = currentUser,
                                                discoverableUsers = discoverableUsers,
                                                suggestions = suggestions,
                                                friendIds = friendIds,
                                                friendRequests = friendRequests,
                                                feedState = feedState,
                                                onViewProfile = navigateToProfile
                                            )

                                            ConnectHubSection.FRIENDS -> FriendsScreen(
                                                viewModel = viewModel,
                                                currentUser = currentUser,
                                                friendships = friendships,
                                                friendRequests = friendRequests,
                                                discoverableUsers = discoverableUsers,
                                                onViewProfile = navigateToProfile,
                                                onOpenConversation = openConversation,
                                                onNavigateToExplore = { currentSection = ConnectHubSection.EXPLORE }
                                            )

                                            ConnectHubSection.MESSAGES -> MessagesScreen(
                                                viewModel = viewModel,
                                                currentUser = currentUser,
                                                conversations = conversations,
                                                selectedConversationId = selectedConversationId,
                                                messages = activeMessages,
                                                isBusy = isBusy,
                                                uploadProgress = uploadProgress,
                                                onSelectConversation = { id ->
                                                    selectedConversationId = id
                                                    viewModel.selectConversation(id)
                                                },
                                                onViewProfile = navigateToProfile
                                            )

                                            ConnectHubSection.NOTIFICATIONS -> NotificationsScreen(
                                                viewModel = viewModel,
                                                notifications = notifications,
                                                onNotificationClick = handleNotificationClick
                                            )

                                            ConnectHubSection.PROFILE -> ProfileScreen(
                                                viewModel = viewModel,
                                                viewedUserId = currentUser.uid,
                                                currentUser = currentUser,
                                                friendIds = friendIds,
                                                friendRequests = friendRequests,
                                                feedState = feedState,
                                                likedPostIds = likedPostIds,
                                                comments = activeComments,
                                                isBusy = isBusy,
                                                uploadProgress = uploadProgress,
                                                onBack = null,
                                                onOpenConversation = openConversation,
                                                onOpenSettings = { currentSection = ConnectHubSection.SETTINGS },
                                                onAuthorClick = navigateToProfile
                                            )

                                            ConnectHubSection.SETTINGS -> SettingsScreen(
                                                viewModel = viewModel,
                                                currentUser = currentUser,
                                                privateAccount = privateAccount,
                                                blockedUsers = blockedUsers,
                                                themePreference = themePreference,
                                                isBusy = isBusy,
                                                onEditProfile = {
                                                    viewedProfileUserId = null
                                                    currentSection = ConnectHubSection.PROFILE
                                                },
                                                onSignedOut = {}
                                            )
                                        }
                                    }
                                }
                            }

                            if (showRightSidebar &&
                                viewedProfileUserId == null &&
                                currentSection != ConnectHubSection.MESSAGES
                            ) {
                                VerticalDivider()
                                ExpandedRightSidebar(
                                    suggestions = suggestions,
                                    notifications = notifications,
                                    onAddFriend = { viewModel.sendFriendRequest(it) },
                                    onViewProfile = navigateToProfile,
                                    onNotificationClick = handleNotificationClick,
                                    onSeeAllExplore = { currentSection = ConnectHubSection.EXPLORE },
                                    onSeeAllNotifications = { currentSection = ConnectHubSection.NOTIFICATIONS }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpandedRightSidebar(
    suggestions: List<SuggestedPerson>,
    notifications: List<AppNotification>,
    onAddFriend: (UserProfile) -> Unit,
    onViewProfile: (String) -> Unit,
    onNotificationClick: (AppNotification) -> Unit,
    onSeeAllExplore: () -> Unit,
    onSeeAllNotifications: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .width(320.dp)
            .fillMaxHeight()
            .testTag("desktop_right_sidebar"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("People You May Know", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onSeeAllExplore) { Text("See all") }
            }
        }

        if (suggestions.isEmpty()) {
            item {
                Text(
                    "No new suggestions right now.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(suggestions.take(4), key = { "side_sug_${it.profile.uid}" }) { item ->
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewProfile(item.profile.uid) }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(item.profile.displayName, item.profile.photoUrl, size = 40.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                item.profile.displayName,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                "@${item.profile.username}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                        OutlinedButton(onClick = { onAddFriend(item.profile) }) {
                            Icon(Icons.Rounded.PersonAdd, "Add", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        item {
            HorizontalDivider()
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recent Activity", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onSeeAllNotifications) { Text("See all") }
            }
        }

        if (notifications.isEmpty()) {
            item {
                Text(
                    "You're all caught up!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(notifications.take(5), key = { "side_notif_${it.id}" }) { notif ->
                Surface(
                    color = if (notif.read) MaterialTheme.colorScheme.surface
                    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNotificationClick(notif) }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(notif.actorName, notif.actorPhotoUrl, size = 32.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                notif.description,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                formatTimestamp(notif.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
