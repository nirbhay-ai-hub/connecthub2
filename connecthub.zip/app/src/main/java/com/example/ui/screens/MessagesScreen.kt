package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayCircleFilled
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MediaItem
import com.example.data.model.ReportTargetType
import com.example.data.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FullscreenMediaDialog
import com.example.ui.components.ReportDialog
import com.example.ui.components.UserAvatar
import com.example.ui.components.formatTimestamp
import com.example.viewmodel.ConnectHubViewModel

@Composable
fun MessagesScreen(
    viewModel: ConnectHubViewModel,
    currentUser: UserProfile,
    conversations: List<Conversation>,
    selectedConversationId: String?,
    messages: List<ChatMessage>,
    isBusy: Boolean,
    uploadProgress: Float?,
    onSelectConversation: (String?) -> Unit,
    onViewProfile: (String) -> Unit
) {
    val activeConversation = remember(conversations, selectedConversationId) {
        conversations.firstOrNull { it.id == selectedConversationId }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .testTag("messages_screen")
    ) {
        val isWide = maxWidth >= 720.dp

        if (isWide) {
            Row(modifier = Modifier.fillMaxSize()) {
                ConversationListPane(
                    currentUserId = currentUser.uid,
                    conversations = conversations,
                    selectedId = selectedConversationId,
                    onSelect = { onSelectConversation(it) },
                    modifier = Modifier
                        .width(320.dp)
                        .fillMaxHeight()
                )
                VerticalDivider()
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    if (activeConversation != null) {
                        ChatThreadPane(
                            viewModel = viewModel,
                            currentUser = currentUser,
                            conversation = activeConversation,
                            messages = messages,
                            isBusy = isBusy,
                            uploadProgress = uploadProgress,
                            showBackButton = false,
                            onBack = {},
                            onViewProfile = onViewProfile
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            EmptyStateCard(
                                title = "Select a conversation",
                                subtitle = "Pick a friend from the left panel to message in real time."
                            )
                        }
                    }
                }
            }
        } else {
            if (activeConversation != null) {
                BackHandler { onSelectConversation(null) }
                ChatThreadPane(
                    viewModel = viewModel,
                    currentUser = currentUser,
                    conversation = activeConversation,
                    messages = messages,
                    isBusy = isBusy,
                    uploadProgress = uploadProgress,
                    showBackButton = true,
                    onBack = { onSelectConversation(null) },
                    onViewProfile = onViewProfile
                )
            } else {
                ConversationListPane(
                    currentUserId = currentUser.uid,
                    conversations = conversations,
                    selectedId = null,
                    onSelect = { onSelectConversation(it) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun ConversationListPane(
    currentUserId: String,
    conversations: List<Conversation>,
    selectedId: String?,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (conversations.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "No messages yet",
                    subtitle = "Once you accept a friend connection, you can start a private real-time chat."
                )
            }
        } else {
            items(conversations, key = { it.id }) { conv ->
                val unread = conv.unreadFor(currentUserId)
                val isSelected = conv.id == selectedId
                Surface(
                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    else MaterialTheme.colorScheme.surface,
                    shape = MaterialTheme.shapes.medium,
                    tonalElevation = if (isSelected) 2.dp else 0.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(conv.id) }
                        .testTag("conversation_item_${conv.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            name = conv.partnerName(currentUserId),
                            photoUrl = conv.partnerPhoto(currentUserId),
                            size = 48.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = conv.partnerName(currentUserId),
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = formatTimestamp(conv.lastMessageAt),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = conv.lastMessageText,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (unread > 0) FontWeight.SemiBold else FontWeight.Normal,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                if (unread > 0) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Badge { Text("$unread") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatThreadPane(
    viewModel: ConnectHubViewModel,
    currentUser: UserProfile,
    conversation: Conversation,
    messages: List<ChatMessage>,
    isBusy: Boolean,
    uploadProgress: Float?,
    showBackButton: Boolean,
    onBack: () -> Unit,
    onViewProfile: (String) -> Unit
) {
    val partnerId = conversation.partnerId(currentUser.uid)
    val partnerName = conversation.partnerName(currentUser.uid)
    val partnerUsername = conversation.partnerUsername(currentUser.uid)
    val partnerPhoto = conversation.partnerPhoto(currentUser.uid)

    var messageDraft by remember { mutableStateOf("") }
    var attachedUri by remember { mutableStateOf<Uri?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    var reportMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var activeMedia by remember { mutableStateOf<MediaItem?>(null) }

    val listState = rememberLazyListState()

    val mediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) attachedUri = uri }
    )

    LaunchedEffect(conversation.id, messages.size) {
        viewModel.markConversationRead(conversation, messages)
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showBackButton) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back to conversations")
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { if (partnerId.isNotBlank()) onViewProfile(partnerId) }
                        .padding(horizontal = 6.dp)
                ) {
                    UserAvatar(name = partnerName, photoUrl = partnerPhoto, size = 40.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(partnerName, style = MaterialTheme.typography.titleSmall)
                        if (partnerUsername.isNotBlank()) {
                            Text(
                                "@$partnerUsername",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Rounded.MoreVert, "Chat options")
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Block $partnerName") },
                            leadingIcon = { Icon(Icons.Rounded.Block, null) },
                            onClick = {
                                showMenu = false
                                viewModel.blockUser(
                                    UserProfile(
                                        uid = partnerId,
                                        displayName = partnerName,
                                        username = partnerUsername
                                    )
                                ) { onBack() }
                            }
                        )
                    }
                }
            }
        }
        HorizontalDivider()

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("chat_messages_list"),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.size >= 40) {
                item {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        TextButton(onClick = { viewModel.loadOlderMessages() }) {
                            Text("Load earlier messages")
                        }
                    }
                }
            }
            items(messages, key = { it.id }) { msg ->
                val isMine = msg.senderId == currentUser.uid
                val isReadByPartner = partnerId.isNotBlank() && partnerId in msg.readBy
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (isMine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                        shape = RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isMine) 18.dp else 4.dp,
                            bottomEnd = if (isMine) 4.dp else 18.dp
                        ),
                        modifier = Modifier
                            .widthIn(max = 300.dp)
                            .clickable(enabled = !isMine) { reportMsg = msg }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            if (!msg.mediaUrl.isNullOrBlank()) {
                                val item = MediaItem(
                                    url = msg.mediaUrl,
                                    type = msg.mediaType ?: "IMAGE",
                                    name = "Chat attachment"
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(170.dp)
                                        .clip(MaterialTheme.shapes.small)
                                        .background(Color.Black.copy(alpha = 0.25f))
                                        .clickable { activeMedia = item },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (item.type == "VIDEO") {
                                        Icon(
                                            Icons.Rounded.PlayCircleFilled,
                                            "Play video",
                                            tint = Color.White,
                                            modifier = Modifier.size(44.dp)
                                        )
                                    } else {
                                        AsyncImage(
                                            model = item.url,
                                            contentDescription = "Chat image",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                                if (msg.text.isNotBlank()) Spacer(modifier = Modifier.height(6.dp))
                            }
                            if (msg.text.isNotBlank()) {
                                Text(msg.text, style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.End,
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text(
                                    text = formatTimestamp(msg.createdAt),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isMine) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.78f)
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (isMine) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = if (isReadByPartner) Icons.Rounded.DoneAll else Icons.Rounded.Done,
                                        contentDescription = if (isReadByPartner) "Read" else "Sent",
                                        tint = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (uploadProgress != null) {
            LinearProgressIndicator(progress = { uploadProgress }, modifier = Modifier.fillMaxWidth())
        }

        if (attachedUri != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = attachedUri,
                    contentDescription = "Pending attachment",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(MaterialTheme.shapes.small)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Media attached", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                IconButton(onClick = { attachedUri = null }) {
                    Icon(Icons.Rounded.Close, "Remove attachment")
                }
            }
        }

        // Input bar
        HorizontalDivider()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                },
                modifier = Modifier.testTag("chat_attach_button")
            ) {
                Icon(Icons.Rounded.AttachFile, "Attach photo or video")
            }
            OutlinedTextField(
                value = messageDraft,
                onValueChange = { messageDraft = it.take(2000) },
                placeholder = { Text("Message $partnerName...") },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_message_input")
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    viewModel.sendChatMessage(conversation, messageDraft, attachedUri) {
                        messageDraft = ""
                        attachedUri = null
                    }
                },
                enabled = !isBusy && (messageDraft.isNotBlank() || attachedUri != null),
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = if (!isBusy && (messageDraft.isNotBlank() || attachedUri != null))
                            MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape
                    )
                    .testTag("chat_send_button")
            ) {
                if (isBusy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    Icon(
                        Icons.AutoMirrored.Rounded.Send,
                        "Send message",
                        tint = if (messageDraft.isNotBlank() || attachedUri != null)
                            MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }

    reportMsg?.let { msg ->
        ReportDialog(
            title = "Report message",
            onDismiss = { reportMsg = null },
            onSubmit = { reason ->
                viewModel.submitReport(ReportTargetType.MESSAGE, msg.id, msg.senderId, reason)
                reportMsg = null
            }
        )
    }

    FullscreenMediaDialog(media = activeMedia, onDismiss = { activeMedia = null })
}
