package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.FriendRequest
import com.example.data.model.FriendRequestStatus
import com.example.data.model.Post
import com.example.data.model.PostVisibility
import com.example.data.model.SuggestedPerson
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.UserAvatar
import com.example.viewmodel.ConnectHubViewModel

@Composable
fun ExploreScreen(
    viewModel: ConnectHubViewModel,
    currentUser: UserProfile,
    discoverableUsers: List<UserProfile>,
    suggestions: List<SuggestedPerson>,
    friendIds: Set<String>,
    friendRequests: List<FriendRequest>,
    feedState: UiState<List<Post>>,
    onViewProfile: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val pendingSentIds = remember(friendRequests, currentUser.uid) {
        friendRequests.filter {
            it.status == FriendRequestStatus.PENDING.name && it.senderId == currentUser.uid
        }.map { it.receiverId }.toSet()
    }
    val pendingIncomingMap = remember(friendRequests, currentUser.uid) {
        friendRequests.filter {
            it.status == FriendRequestStatus.PENDING.name && it.receiverId == currentUser.uid
        }.associateBy { it.senderId }
    }

    val searchResults = remember(searchQuery, discoverableUsers) {
        val q = searchQuery.trim().lowercase().removePrefix("@")
        if (q.isEmpty()) emptyList()
        else discoverableUsers.filter {
            it.displayNameLowercase.contains(q) || it.usernameLowercase.contains(q)
        }
    }

    val publicPosts = remember(feedState) {
        ((feedState as? UiState.Success)?.data ?: emptyList())
            .filter { it.visibility == PostVisibility.PUBLIC.name }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("explore_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search people by name or @username...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = MaterialTheme.shapes.large,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("explore_search_input")
            )
        }

        if (searchQuery.isNotBlank()) {
            item {
                Text(
                    text = "Search Results (${searchResults.size})",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            if (searchResults.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "No matching members found",
                        subtitle = "Try searching a different display name or @username."
                    )
                }
            } else {
                items(searchResults, key = { it.uid }) { person ->
                    PersonRowCard(
                        person = person,
                        isFriend = person.uid in friendIds,
                        isPendingSent = person.uid in pendingSentIds,
                        incomingRequest = pendingIncomingMap[person.uid],
                        onAddFriend = { viewModel.sendFriendRequest(person) },
                        onAccept = { req -> viewModel.acceptFriendRequest(req) },
                        onViewProfile = { onViewProfile(person.uid) }
                    )
                }
            }
        } else {
            item {
                Column {
                    Text("People You May Know", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "Based on shared interests, mutual connections, and recently joined members",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (suggestions.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "No new suggestions right now",
                        subtitle = "When more registered members join ConnectHub or update their discovery settings, they'll appear here."
                    )
                }
            } else {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(suggestions, key = { it.profile.uid }) { suggestion ->
                            SuggestedPersonCard(
                                suggestion = suggestion,
                                onAddFriend = { viewModel.sendFriendRequest(suggestion.profile) },
                                onViewProfile = { onViewProfile(suggestion.profile.uid) }
                            )
                        }
                    }
                }
            }

            if (discoverableUsers.isNotEmpty()) {
                item {
                    Text(
                        text = "Discover Community",
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                items(discoverableUsers.take(15), key = { "dir_${it.uid}" }) { person ->
                    PersonRowCard(
                        person = person,
                        isFriend = person.uid in friendIds,
                        isPendingSent = person.uid in pendingSentIds,
                        incomingRequest = pendingIncomingMap[person.uid],
                        onAddFriend = { viewModel.sendFriendRequest(person) },
                        onAccept = { req -> viewModel.acceptFriendRequest(req) },
                        onViewProfile = { onViewProfile(person.uid) }
                    )
                }
            }

            if (publicPosts.isNotEmpty()) {
                item {
                    Text(
                        text = "Public Highlights (${publicPosts.size})",
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                items(publicPosts.take(10), key = { "pub_${it.id}" }) { post ->
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onViewProfile(post.authorId) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                UserAvatar(name = post.authorName, photoUrl = post.authorPhotoUrl, size = 34.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(post.authorName, style = MaterialTheme.typography.titleSmall)
                                    Text("@${post.authorUsername}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            if (post.text.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(post.text, style = MaterialTheme.typography.bodyMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SuggestedPersonCard(
    suggestion: SuggestedPerson,
    onAddFriend: () -> Unit,
    onViewProfile: () -> Unit
) {
    val p = suggestion.profile
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .width(210.dp)
            .testTag("suggestion_card_${p.uid}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            UserAvatar(
                name = p.displayName,
                photoUrl = p.photoUrl,
                size = 64.dp,
                modifier = Modifier.clickable(onClick = onViewProfile)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = p.displayName,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "@${p.username}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(6.dp))
            val metaText = buildString {
                if (suggestion.mutualFriendsCount > 0) {
                    append("${suggestion.mutualFriendsCount} mutual")
                }
                if (suggestion.sharedInterestsCount > 0) {
                    if (isNotEmpty()) append(" • ")
                    append("${suggestion.sharedInterestsCount} shared")
                }
                if (isEmpty()) append("Recently joined")
            }
            AssistChip(
                onClick = onViewProfile,
                label = { Text(metaText, style = MaterialTheme.typography.labelSmall) }
            )
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onAddFriend,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_friend_button_${p.uid}")
            ) {
                Icon(Icons.Rounded.PersonAdd, null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add Friend")
            }
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedButton(
                onClick = onViewProfile,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("view_profile_button_${p.uid}")
            ) {
                Text("View Profile")
            }
        }
    }
}

@Composable
private fun PersonRowCard(
    person: UserProfile,
    isFriend: Boolean,
    isPendingSent: Boolean,
    incomingRequest: FriendRequest?,
    onAddFriend: () -> Unit,
    onAccept: (FriendRequest) -> Unit,
    onViewProfile: () -> Unit
) {
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onViewProfile)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UserAvatar(name = person.displayName, photoUrl = person.photoUrl, size = 48.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(person.displayName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("@${person.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (person.bio.isNotBlank()) {
                    Text(person.bio, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            when {
                isFriend -> OutlinedButton(onClick = onViewProfile) { Text("Friends") }
                incomingRequest != null -> Button(onClick = { onAccept(incomingRequest) }) { Text("Accept") }
                isPendingSent -> OutlinedButton(onClick = onViewProfile) { Text("Requested") }
                else -> Button(onClick = onAddFriend) { Text("Add") }
            }
        }
    }
}
