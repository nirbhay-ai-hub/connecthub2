package com.example.ui.auth

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.viewmodel.ConnectHubViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.delay

private val SUGGESTED_INTERESTS = listOf(
    "Technology", "Design", "Photography", "Travel", "Music",
    "Fitness", "Books", "Gaming", "Cooking", "Startups", "Film", "Art"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileSetupScreen(
    viewModel: ConnectHubViewModel,
    isBusy: Boolean,
    uploadProgress: Float?,
    errorMessage: String?,
    onSignOut: () -> Unit
) {
    val authUser = Firebase.auth.currentUser
    val suggestedDefaultHandle = remember(authUser) {
        val raw = (authUser?.email?.substringBefore("@") ?: authUser?.displayName ?: "member")
            .lowercase()
            .replace(Regex("[^a-z0-9_]"), "_")
            .trim('_')
        if (raw.length >= 3) raw.take(20) else "user_${authUser?.uid?.take(6) ?: "hub"}"
    }

    var fullName by remember { mutableStateOf(authUser?.displayName ?: "") }
    var username by remember { mutableStateOf(suggestedDefaultHandle) }
    var bio by remember { mutableStateOf("") }
    var selectedInterests by remember { mutableStateOf(setOf("Technology", "Design")) }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var discoverable by remember { mutableStateOf(true) }
    var acceptedTerms by remember { mutableStateOf(false) }

    var usernameStatus by remember { mutableStateOf<Boolean?>(null) }
    var checkingUsername by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) photoUri = uri }
    )

    LaunchedEffect(username) {
        val cleaned = username.trim()
        if (!cleaned.matches(Regex("^[a-zA-Z0-9_]{3,30}$"))) {
            usernameStatus = null
            return@LaunchedEffect
        }
        checkingUsername = true
        delay(350)
        val res = viewModel.checkUsernameAvailable(cleaned)
        usernameStatus = res.getOrNull()
        checkingUsername = false
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.widthIn(max = 540.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Complete your profile",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Choose a unique @username to join ConnectHub",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = onSignOut) {
                        Text("Sign out")
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Optional Avatar Picker
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                            .clickable {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                            .testTag("setup_avatar_picker"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (photoUri != null) {
                            AsyncImage(
                                model = photoUri,
                                contentDescription = "Selected profile picture",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.AddAPhoto,
                                contentDescription = "Pick profile picture",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Profile picture (optional)", style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedButton(
                            onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        ) {
                            Text(if (photoUri == null) "Choose photo" else "Change photo")
                        }
                    }
                }

                if (uploadProgress != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { uploadProgress },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it.take(80) },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setup_fullname_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.filter { ch -> ch.isLetterOrDigit() || ch == '_' }.take(30) },
                    label = { Text("Unique Username") },
                    prefix = { Text("@") },
                    singleLine = true,
                    trailingIcon = {
                        when {
                            checkingUsername -> CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            usernameStatus == true -> Icon(Icons.Rounded.CheckCircle, "Available", tint = MaterialTheme.colorScheme.tertiary)
                            usernameStatus == false -> Icon(Icons.Rounded.ErrorOutline, "Taken", tint = MaterialTheme.colorScheme.error)
                        }
                    },
                    supportingText = {
                        val msg = when {
                            username.length < 3 -> "Minimum 3 characters (letters, numbers, underscores)"
                            usernameStatus == true -> "@${username.lowercase()} is available"
                            usernameStatus == false -> "@${username.lowercase()} is already taken"
                            else -> "Case-insensitive unique handle"
                        }
                        Text(msg)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setup_username_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it.take(300) },
                    label = { Text("Bio (optional)") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setup_bio_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("Interests (helps suggest connections)", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SUGGESTED_INTERESTS.forEach { interest ->
                        val selected = interest in selectedInterests
                        FilterChip(
                            selected = selected,
                            onClick = {
                                selectedInterests = if (selected) selectedInterests - interest else selectedInterests + interest
                            },
                            label = { Text(interest) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Discoverable Profile", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Allow registered users to find you in People You May Know",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = discoverable,
                            onCheckedChange = { discoverable = it },
                            modifier = Modifier.testTag("setup_discoverable_switch")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { acceptedTerms = !acceptedTerms }
                        .padding(vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = acceptedTerms,
                        onCheckedChange = { acceptedTerms = it },
                        modifier = Modifier.testTag("setup_terms_checkbox")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "I agree to ConnectHub's Terms of Service and Privacy Policy.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                val displayErr = validationError ?: errorMessage
                if (!displayErr.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = displayErr,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        validationError = when {
                            fullName.trim().isEmpty() -> "Please enter your full name."
                            username.trim().length < 3 -> "Username must be at least 3 characters."
                            usernameStatus == false -> "Please choose a different username."
                            !acceptedTerms -> "Please accept the Terms and Privacy Policy."
                            else -> null
                        }
                        if (validationError == null) {
                            viewModel.completeInitialProfile(
                                displayName = fullName,
                                username = username,
                                bio = bio,
                                interests = selectedInterests.toList(),
                                photoUri = photoUri,
                                email = authUser?.email ?: "",
                                acceptedTerms = acceptedTerms,
                                profileDiscoverable = discoverable
                            )
                        }
                    },
                    enabled = !isBusy,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("setup_submit_button")
                ) {
                    if (isBusy) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text("Create ConnectHub Account", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }
    }
}
