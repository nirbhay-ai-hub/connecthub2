package com.example.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.config.MediaConfig
import com.example.data.model.AppNotification
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.FriendRequest
import com.example.data.model.FriendRequestStatus
import com.example.data.model.Friendship
import com.example.data.model.MediaItem
import com.example.data.model.Post
import com.example.data.model.PostComment
import com.example.data.model.PostVisibility
import com.example.data.model.PrivateAccount
import com.example.data.model.ProfileVisibility
import com.example.data.model.ReportTargetType
import com.example.data.model.SuggestedPerson
import com.example.data.model.ThemePreference
import com.example.data.model.UiState
import com.example.data.model.UserBlock
import com.example.data.model.UserProfile
import com.example.data.repository.AuthPreferencesRepository
import com.example.data.repository.ChatRepository
import com.example.data.repository.MediaStorageRepository
import com.example.data.repository.NotificationRepository
import com.example.data.repository.ProfileRepository
import com.example.data.repository.SocialRepository
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class ConnectHubViewModel(
    val currentUserId: String,
    private val profileRepo: ProfileRepository,
    private val socialRepo: SocialRepository,
    private val chatRepo: ChatRepository,
    private val notificationRepo: NotificationRepository,
    private val mediaRepo: MediaStorageRepository,
    private val prefsRepo: AuthPreferencesRepository
) : ViewModel() {

    private fun <T> Flow<T>.unwrapFirestoreError(tag: String, fallback: T): Flow<T> =
        this.catch { error ->
            val fsError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (fsError == null && error is CancellationException) throw error
            Log.w(tag, "Firestore stream error", fsError ?: error)
            emit(fallback)
        }

    val themePreference: StateFlow<ThemePreference> = prefsRepo.themePreference
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), ThemePreference.SYSTEM)

    val currentProfileState: StateFlow<UiState<UserProfile?>> =
        profileRepo.observeUserProfile(currentUserId)
            .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
            .catch { error ->
                val fsError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (fsError == null && error is CancellationException) throw error
                val root = fsError ?: error
                Log.w(TAG, "Profile stream error", root)
                emit(UiState.Error(root.message ?: "Failed to load profile"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val privateAccount: StateFlow<PrivateAccount?> =
        profileRepo.observePrivateAccount(currentUserId)
            .unwrapFirestoreError("PrivateAcc", null)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val blockedUsers: StateFlow<List<UserBlock>> =
        profileRepo.observeBlockedUsers(currentUserId)
            .unwrapFirestoreError("Blocks", emptyList())
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val blockedIdsFlow: Flow<Set<String>> = blockedUsers.map { list ->
        list.map { it.blockedId }.toSet()
    }

    val discoverableUsers: StateFlow<List<UserProfile>> =
        combine(
            profileRepo.observeDiscoverableUsers().unwrapFirestoreError("Discover", emptyList()),
            blockedIdsFlow
        ) { users, blocked ->
            users.filter { it.uid != currentUserId && it.uid !in blocked }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val friendRequests: StateFlow<List<FriendRequest>> =
        socialRepo.observeFriendRequests(currentUserId)
            .unwrapFirestoreError("FriendReqs", emptyList())
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val friendships: StateFlow<List<Friendship>> =
        socialRepo.observeFriendships(currentUserId)
            .unwrapFirestoreError("Friendships", emptyList())
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val friendIds: StateFlow<Set<String>> = friendships
        .map { list -> list.map { it.otherUserId(currentUserId) }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptySet())

    val suggestions: StateFlow<List<SuggestedPerson>> = combine(
        currentProfileState,
        discoverableUsers,
        friendIds,
        friendRequests,
        blockedIdsFlow
    ) { profileUi, users, friends, requests, blocked ->
        val me = (profileUi as? UiState.Success)?.data
        val myInterests = me?.interests?.map { it.lowercase() }?.toSet() ?: emptySet()
        val pendingIds = requests.filter { it.status == FriendRequestStatus.PENDING.name }
            .flatMap { it.memberIds }
            .toSet()

        users.filter { u ->
            u.uid != currentUserId &&
                u.uid !in friends &&
                u.uid !in pendingIds &&
                u.uid !in blocked
        }.map { candidate ->
            val sharedInterests = candidate.interests.count { it.lowercase() in myInterests }
            val mutualEstimate = if (candidate.connectionCount > 0 && friends.isNotEmpty()) {
                minOf(candidate.connectionCount.toInt(), friends.size).coerceAtMost(3)
            } else 0
            val score = (sharedInterests * 3) + (mutualEstimate * 2) + 1
            SuggestedPerson(
                profile = candidate,
                mutualFriendsCount = mutualEstimate,
                sharedInterestsCount = sharedInterests,
                score = score
            )
        }.sortedByDescending { it.score }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val feedLimit = MutableStateFlow(25L)

    val feedState: StateFlow<UiState<List<Post>>> = feedLimit.flatMapLatest { limit ->
        combine(
            socialRepo.observePublicPosts(limit).unwrapFirestoreError("PubPosts", emptyList()),
            socialRepo.observeFriendAudiencePosts(currentUserId, limit).unwrapFirestoreError("FriendPosts", emptyList()),
            socialRepo.observeOwnPosts(currentUserId, limit).unwrapFirestoreError("OwnPosts", emptyList()),
            blockedIdsFlow
        ) { pub, friendPosts, own, blocked ->
            val combined = (pub + friendPosts + own)
                .distinctBy { it.id }
                .filter { it.authorId !in blocked }
                .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            UiState.Success(combined) as UiState<List<Post>>
        }
    }.catch { error ->
        val fsError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (fsError == null && error is CancellationException) throw error
        emit(UiState.Error((fsError ?: error).message ?: "Failed to load feed"))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val _likedPostIds = MutableStateFlow<Set<String>>(emptySet())
    val likedPostIds: StateFlow<Set<String>> = _likedPostIds.asStateFlow()

    val conversations: StateFlow<List<Conversation>> =
        combine(
            chatRepo.observeConversations(currentUserId).unwrapFirestoreError("Convos", emptyList()),
            blockedIdsFlow
        ) { convs, blocked ->
            convs.filter { conv -> conv.partnerId(currentUserId) !in blocked }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val notifications: StateFlow<List<AppNotification>> =
        notificationRepo.observeNotifications(currentUserId)
            .unwrapFirestoreError("Notifs", emptyList())
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val activeConversationId = MutableStateFlow<String?>(null)
    private val messageLimit = MutableStateFlow(40L)

    val activeMessages: StateFlow<List<ChatMessage>> =
        combine(activeConversationId, messageLimit) { id, limit -> id to limit }
            .flatMapLatest { (convId, limit) ->
                if (convId.isNullOrBlank()) flowOf(emptyList())
                else chatRepo.observeMessages(convId, currentUserId, limit)
                    .unwrapFirestoreError("Messages", emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val activeCommentsPost = MutableStateFlow<Post?>(null)
    val activeComments: StateFlow<List<PostComment>> =
        activeCommentsPost.flatMapLatest { post ->
            if (post == null) flowOf(emptyList())
            else socialRepo.observeComments(post, currentUserId)
                .unwrapFirestoreError("Comments", emptyList())
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _uploadProgress = MutableStateFlow<Float?>(null)
    val uploadProgress: StateFlow<Float?> = _uploadProgress.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    init {
        viewModelScope.launch {
            combine(currentProfileState, friendships) { profState, friendList ->
                (profState as? UiState.Success)?.data to friendList.size.toLong()
            }.collect { (profile, actualCount) ->
                if (profile != null && profile.connectionCount != actualCount) {
                    profileRepo.syncConnectionCount(currentUserId, actualCount)
                }
            }
        }
    }

    fun clearMessage() {
        _actionMessage.value = null
    }

    fun setThemePreference(pref: ThemePreference) {
        viewModelScope.launch { prefsRepo.setThemePreference(pref) }
    }

    fun loadMoreFeed() {
        feedLimit.value = (feedLimit.value + 20L).coerceAtMost(150L)
    }

    fun selectConversation(conversationId: String?) {
        activeConversationId.value = conversationId
        messageLimit.value = 40L
    }

    fun loadOlderMessages() {
        messageLimit.value = (messageLimit.value + 40L).coerceAtMost(250L)
    }

    fun openComments(post: Post?) {
        activeCommentsPost.value = post
    }

    fun refreshLikeStatus(postId: String) {
        viewModelScope.launch {
            val liked = socialRepo.hasUserLikedPost(postId, currentUserId)
            _likedPostIds.value = if (liked) _likedPostIds.value + postId else _likedPostIds.value - postId
        }
    }

    fun completeInitialProfile(
        displayName: String,
        username: String,
        bio: String,
        interests: List<String>,
        photoUri: Uri?,
        email: String,
        acceptedTerms: Boolean,
        profileDiscoverable: Boolean
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            var uploadedUrl: String? = null
            if (photoUri != null) {
                val upResult = mediaRepo.uploadProfileImage(currentUserId, photoUri, "avatar") {
                    _uploadProgress.value = it
                }
                _uploadProgress.value = null
                if (upResult.isFailure) {
                    _actionMessage.value = upResult.exceptionOrNull()?.localizedMessage ?: "Avatar upload failed"
                    _isBusy.value = false
                    return@launch
                }
                uploadedUrl = upResult.getOrNull()
            }
            val result = profileRepo.createInitialProfile(
                displayName = displayName,
                username = username,
                bio = bio,
                interests = interests,
                photoUrl = uploadedUrl,
                email = email,
                acceptedTerms = acceptedTerms,
                profileDiscoverable = profileDiscoverable
            )
            _isBusy.value = false
            result.onFailure {
                _actionMessage.value = it.localizedMessage ?: "Failed to create profile"
            }
        }
    }

    fun updateProfile(
        currentProfile: UserProfile,
        displayName: String,
        username: String,
        bio: String,
        interests: List<String>,
        newPhotoUri: Uri?,
        newCoverUri: Uri?,
        onDone: () -> Unit
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            var photoUrl = currentProfile.photoUrl
            var coverUrl = currentProfile.coverUrl

            if (newPhotoUri != null) {
                val res = mediaRepo.uploadProfileImage(currentUserId, newPhotoUri, "avatar") {
                    _uploadProgress.value = it
                }
                _uploadProgress.value = null
                if (res.isFailure) {
                    _actionMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Photo upload failed"
                    _isBusy.value = false
                    return@launch
                }
                photoUrl = res.getOrNull()
            }
            if (newCoverUri != null) {
                val res = mediaRepo.uploadProfileImage(currentUserId, newCoverUri, "cover") {
                    _uploadProgress.value = it
                }
                _uploadProgress.value = null
                if (res.isFailure) {
                    _actionMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Cover upload failed"
                    _isBusy.value = false
                    return@launch
                }
                coverUrl = res.getOrNull()
            }

            val result = profileRepo.updateProfile(
                currentProfile = currentProfile,
                displayName = displayName,
                username = username,
                bio = bio,
                interests = interests,
                photoUrl = photoUrl,
                coverUrl = coverUrl
            )
            _isBusy.value = false
            result.onSuccess {
                _actionMessage.value = "Profile updated"
                onDone()
            }.onFailure {
                _actionMessage.value = it.localizedMessage ?: "Could not update profile"
            }
        }
    }

    fun updatePrivacySettings(
        visibility: ProfileVisibility,
        discoverable: Boolean,
        defaultPostVisibility: PostVisibility,
        allowUnknownMessages: Boolean
    ) {
        viewModelScope.launch {
            profileRepo.updatePrivacySettings(visibility, discoverable, defaultPostVisibility, allowUnknownMessages)
                .onSuccess { _actionMessage.value = "Privacy settings saved" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to update privacy" }
        }
    }

    fun updateNotificationPrefs(friendReqs: Boolean, messages: Boolean, postActivity: Boolean) {
        viewModelScope.launch {
            profileRepo.updateNotificationPreferences(friendReqs, messages, postActivity)
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to save preferences" }
        }
    }

    fun sendFriendRequest(target: UserProfile) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            socialRepo.sendFriendRequest(me, target)
                .onSuccess { _actionMessage.value = "Friend request sent to ${target.displayName}" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not send request" }
        }
    }

    fun acceptFriendRequest(request: FriendRequest) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            socialRepo.acceptFriendRequest(request, me)
                .onSuccess { _actionMessage.value = "You are now friends with ${request.senderName}" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not accept request" }
        }
    }

    fun rejectFriendRequest(requestId: String) {
        viewModelScope.launch {
            socialRepo.rejectFriendRequest(requestId)
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Action failed" }
        }
    }

    fun cancelFriendRequest(requestId: String) {
        viewModelScope.launch {
            socialRepo.cancelFriendRequest(requestId)
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Action failed" }
        }
    }

    fun removeFriend(friendId: String) {
        viewModelScope.launch {
            socialRepo.removeFriend(currentUserId, friendId)
                .onSuccess { _actionMessage.value = "Friend removed" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to remove friend" }
        }
    }

    fun createPost(
        text: String,
        mediaUris: List<Uri>,
        visibility: PostVisibility,
        onSuccess: () -> Unit
    ) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            _isBusy.value = true
            val postId = UUID.randomUUID().toString()
            val uploaded = mutableListOf<MediaItem>()
            for ((idx, uri) in mediaUris.take(MediaConfig.MAX_POST_ATTACHMENTS).withIndex()) {
                val res = mediaRepo.uploadPostMedia(currentUserId, postId, uri) { p ->
                    _uploadProgress.value = (idx + p) / mediaUris.size.toFloat()
                }
                if (res.isFailure) {
                    _uploadProgress.value = null
                    _isBusy.value = false
                    _actionMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Media upload failed"
                    return@launch
                }
                res.getOrNull()?.let { uploaded.add(it) }
            }
            _uploadProgress.value = null
            val result = socialRepo.createPost(
                postId = postId,
                author = me,
                text = text,
                media = uploaded,
                visibility = visibility,
                friendIds = friendIds.value.toList()
            )
            _isBusy.value = false
            result.onSuccess {
                _actionMessage.value = "Post published"
                onSuccess()
            }.onFailure {
                _actionMessage.value = it.localizedMessage ?: "Could not publish post"
            }
        }
    }

    fun editPost(post: Post, newText: String, newVisibility: PostVisibility, onDone: () -> Unit) {
        viewModelScope.launch {
            socialRepo.updatePostText(post, newText, newVisibility, friendIds.value.toList())
                .onSuccess {
                    _actionMessage.value = "Post updated"
                    onDone()
                }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not update post" }
        }
    }

    fun deletePost(postId: String) {
        viewModelScope.launch {
            socialRepo.deletePost(postId)
                .onSuccess { _actionMessage.value = "Post deleted" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not delete post" }
        }
    }

    fun sharePost(post: Post) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        if (post.visibility == PostVisibility.PRIVATE.name) {
            _actionMessage.value = "Private posts cannot be shared."
            return
        }
        viewModelScope.launch {
            val shareVisibility = if (post.visibility == PostVisibility.PUBLIC.name) PostVisibility.PUBLIC else PostVisibility.FRIENDS
            socialRepo.createPost(
                author = me,
                text = post.text,
                media = post.media,
                visibility = shareVisibility,
                friendIds = friendIds.value.toList(),
                sharedFromPostId = post.id,
                sharedFromAuthorName = post.authorName
            ).onSuccess {
                _actionMessage.value = "Post shared to your feed"
            }.onFailure {
                _actionMessage.value = it.localizedMessage ?: "Could not share post"
            }
        }
    }

    fun toggleLike(post: Post) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        val currentlyLiked = post.id in _likedPostIds.value
        viewModelScope.launch {
            socialRepo.toggleLike(post, me, currentlyLiked)
                .onSuccess { nowLiked ->
                    _likedPostIds.value = if (nowLiked) _likedPostIds.value + post.id else _likedPostIds.value - post.id
                }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not update like" }
        }
    }

    fun addComment(post: Post, text: String, onDone: () -> Unit) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            socialRepo.addComment(post, me, text)
                .onSuccess { onDone() }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not post comment" }
        }
    }

    fun openOrStartChatWithFriend(partner: UserProfile, onReady: (String) -> Unit) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        if (partner.uid !in friendIds.value) {
            _actionMessage.value = "Accept a friend connection before starting a private chat."
            return
        }
        viewModelScope.launch {
            chatRepo.openOrCreateConversation(me, partner)
                .onSuccess { convId ->
                    selectConversation(convId)
                    onReady(convId)
                }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not open chat" }
        }
    }

    fun sendChatMessage(conversation: Conversation, text: String, mediaUri: Uri?, onSent: () -> Unit) {
        val me = (currentProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            _isBusy.value = true
            var uploaded: MediaItem? = null
            if (mediaUri != null) {
                val res = mediaRepo.uploadChatMedia(conversation.id, currentUserId, mediaUri) {
                    _uploadProgress.value = it
                }
                _uploadProgress.value = null
                if (res.isFailure) {
                    _isBusy.value = false
                    _actionMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Attachment upload failed"
                    return@launch
                }
                uploaded = res.getOrNull()
            }
            val result = chatRepo.sendMessage(conversation, me, text, uploaded)
            _isBusy.value = false
            result.onSuccess { onSent() }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Message failed to send" }
        }
    }

    fun markConversationRead(conversation: Conversation, messages: List<ChatMessage>) {
        viewModelScope.launch {
            chatRepo.markConversationRead(conversation, messages)
        }
    }

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch { notificationRepo.markRead(notificationId) }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch { notificationRepo.markAllRead(notifications.value) }
    }

    fun clearNotifications() {
        viewModelScope.launch { notificationRepo.clearAll(notifications.value) }
    }

    fun blockUser(target: UserProfile, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            profileRepo.blockUser(target)
                .onSuccess {
                    _actionMessage.value = "${target.displayName} has been blocked"
                    onDone()
                }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not block user" }
        }
    }

    fun unblockUser(blockedId: String) {
        viewModelScope.launch {
            profileRepo.unblockUser(blockedId)
                .onSuccess { _actionMessage.value = "User unblocked" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not unblock user" }
        }
    }

    fun submitReport(targetType: ReportTargetType, targetId: String, ownerId: String, reason: String) {
        viewModelScope.launch {
            profileRepo.submitReport(targetType, targetId, ownerId, reason)
                .onSuccess { _actionMessage.value = "Report submitted for moderation review" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Could not submit report" }
        }
    }

    fun deleteAccount(onDeleted: () -> Unit) {
        val me = (currentProfileState.value as? UiState.Success)?.data
        viewModelScope.launch {
            _isBusy.value = true
            val res = profileRepo.deleteAccountData(me?.usernameLowercase ?: "")
            _isBusy.value = false
            res.onSuccess { onDeleted() }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to delete account data" }
        }
    }

    suspend fun checkUsernameAvailable(username: String): Result<Boolean> =
        profileRepo.isUsernameAvailable(username, currentUserId)

    suspend fun fetchProfileById(uid: String): Result<UserProfile?> =
        profileRepo.getProfileById(uid)

    companion object {
        private const val TAG = "ConnectHubVM"
    }
}
